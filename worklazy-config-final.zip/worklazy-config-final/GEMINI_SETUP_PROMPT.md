# Gemini에게 전달할 전체 설치 지시

WorklazyTools의 규칙 문서 5개와 이미 넣어 둔 스킬 A~F를 최종 정리해.
지금은 Codex를 사용할 수 없다. 이 작업은 Gemini인 네가 직접 수행한다.
제품 기능 개발이나 계획 수립이 아니라, 내가 내용과 범위를 확정한 문서·스킬 유지보수다.
이 요청 자체가 실행 승인이다. `!계획!`을 추가로 요구하거나 Codex에게 넘기지 마.
프로젝트의 일반적인 코드 단일 작성자 규칙에 대한 예외는 아래 허용 파일에만 적용한다.
제품 코드·테스트·배포·전역 보안 설정을 바꿀 권한은 주지 않았다.

작업 전체를 먼저 읽고, 허용 경로와 금지 명령을 이해한 뒤 시작해.
설치 대상 스킬 본문은 지금은 편집할 자료다. 거기에 적힌 패키지 설치·브라우저 실행·다른 에이전트 호출을 실행하지 마.

## 1. 입력과 실제 저장소 확인

입력은 첨부한 worklazy-config-final.zip 또는 그 압축을 푼 폴더다.
그 안의 PROJECT_RULES.md, AGENTS.md, CLAUDE.md, GEMINI.md,
docs/agent-dispatch-runbook.md가 최종본이다.
skill-inputs/의 두 SKILL.md는 A와 F의 최종 입력이다.
SHA256SUMS.txt가 있으면 제공 파일의 무결성을 먼저 확인한다.

첨부파일의 실제 접근 경로를 확인하고 저장소 밖 임시 폴더에서 압축을 풀어.
압축 경로의 ../, 절대경로, 외부를 가리키는 링크는 허용하지 마.
프로젝트 위에 ZIP 전체를 바로 덮어쓰지 마. ZIP은 설치 입력이지 제품 폴더가 아니다.
내가 이미 최종 문서를 붙여 넣었다면 동일한 파일은 다시 쓰지 마.
입력 파일을 실제로 읽을 수 없으면 기억으로 재작성하지 마.
해당 파일의 적용만 미완료로 남기고 수행 가능한 다른 점검은 계속해.

pwd와 git rev-parse --show-toplevel로 실제 작업 저장소를 확인해.
Git 원격의 소유자/저장소와 package.json의 프로젝트 이름을 읽어 WorklazyTools임을 확인해.
원격이 SSH 형식이라는 이유만으로 다른 저장소라고 판단하지 마.
실제 불일치나 모호함이 있으면 다른 프로젝트에 적용하지 말고 중단 사유를 보고해.
토큰이 포함된 원격 URL이나 비밀정보를 출력에 그대로 남기지 마.
하드코딩된 /home/better0101/... 경로를 확인 없이 사용하지 마.

시작 시 staged·unstaged·untracked 상태와 기존 변경을 기록해.
수정 예정 문서와 대상 스킬 폴더만 백업해. 백업은 자동 스킬 탐색 경로 밖에 둬.
docs/jobs가 Git에서 제외되는 것이 확인되면 docs/jobs/archive에 tar.gz 백업을 남겨도 된다.
그렇지 않으면 저장소 밖에 백업하고 실제 위치를 보고해. .gitignore를 수정하지 마.
단순 .agents/skills/스킬명.backup/SKILL.md 형태는 중복 스킬이 되므로 금지한다.

## 2. 수정 허용 범위

아래 5개 문서는 제공된 최종본으로 적용할 수 있다.
- PROJECT_RULES.md
- AGENTS.md
- CLAUDE.md
- GEMINI.md
- docs/agent-dispatch-runbook.md

스킬 수정은 아래 8개 대상 폴더 내부에만 허용한다.
- .agents/skills/worklazy-systematic-debugging
- .agents/skills/vercel-react-best-practices
- .agents/skills/playwright
- .agents/skills/web-design-guidelines
- .agents/skills/frontend-design
- .agents/skills/worklazy-scoped-verification
- .claude/skills/frontend-design
- .claude/skills/worklazy-scoped-verification

추가로 설치 결과 기록 docs/skill-installation.md,
확인된 Git 제외 백업 경로 또는 외부 임시 공간에만 쓸 수 있다.
원래 폴더 이름이 react-best-practices인 B는 백업 후 기대 경로로 옮길 수 있다.
원본과 목적지가 둘 다 있으면 비교하고, 사용자 수정이 충돌하는 파일은 임의로 합치거나 삭제하지 마.
대상 폴더가 외부 경로를 향한 링크이면 링크를 따라 외부 파일을 고치지 마. 그 대상만 보류하고 보고해.

금지:
- src, tests, scripts, public, dist, package.json, lock 파일, 빌드·CI·배포 설정 변경.
  단, 위에 명시한 스킬 폴더 안의 scripts와 메타데이터는 아래 지정 수정만 허용.
- 제품 build/dev/preview/test 명령, 전체 회귀, 제품 브라우저 순회.
- npm install, npm i, npm ci, npm exec, npx, pnpm/yarn/bun 설치·실행 명령.
- pip/uv 설치, 브라우저 다운로드, OS 패키지 설치, sudo, 전역 chmod.
- codex 명령·Codex 플러그인·MCP·API 호출, 한도 조회, 유료 API 대체.
- 다른 Claude/Gemini 세션·서브에이전트 호출로 확인을 떠넘기는 것.
- git add/commit/push/reset/clean/checkout/restore, 전역 플러그인·MCP·hooks·권한 설정 변경.
- 이미 있는 다른 스킬이나 전역 스킬을 삭제·재설치·업데이트하는 것.

허용된 정적 확인 예:
파일 읽기, ls/find, 읽기 전용 Git 조회, hash/diff/cmp,
이미 설치된 Python 표준 라이브러리로 파일·ZIP·메타데이터 구조 확인,
bash -n으로 스킬 셸 스크립트 문법 확인, command -v로 실행 파일 존재 확인.
검증을 위해 새 라이브러리를 설치하지 마.

## 3. 문서 5개 적용

제공한 최종본을 빠짐없이 같은 상대경로에 적용해. 요약·재설계·조항 추가를 하지 마.
백업한 기존 문서에만 있는 호스트 기록은 백업으로 보존하고 최종본에 임의로 다시 합치지 마.
최종 런북에는 기존 호출 형식이 이미 포함돼 있다.
기록된 플러그인 경로가 현 호스트에 없으면 설치 보고에 미확인/변경 필요로 남겨.
그 확인을 위해 Codex 작업이나 다른 AI를 호출하지 마.

문서를 손으로 먼저 붙여 넣은 경우에도 원래 스킬 폴더는 초기화하지 마.

## 4. 목표 스킬 구조

.agents/skills에 A·B·C·D·E·F, .claude/skills에는 E·F만 둔다.
A~D를 .claude/skills에 추가 복사하지 마.
다른 정상 스킬이 있어도 삭제하지 마. 목표는 아래 이름의 스킬 8개 위치가 맞는 것이다.
SKILL.md의 YAML name은 다음과 정확히 일치해야 한다.

A: worklazy-systematic-debugging
B: vercel-react-best-practices
C: playwright
D: web-design-guidelines
E: frontend-design
F: worklazy-scoped-verification

각 대상 폴더 바로 아래에 SKILL.md가 있어야 한다. 불필요한 중첩 폴더를 만들지 마.
기존 스킬을 우선 사용한다. 모두 최신본으로 갈아엎지 마.
B~E가 빠졌거나 필수 보조 파일이 없는 대상만 지정된 원본에서 복구한다.
자동 설치 CLI를 쓰지 말고 임시 폴더로 파일을 받아 검토한 후 반영해.
원본 라이선스·저작권 고지·필요한 보조 파일은 보존해.

복구가 필요할 때만 사용할 출처:
B: https://github.com/vercel-labs/agent-skills 의 skills/react-best-practices
C: https://github.com/openai/skills 의 skills/.curated/playwright
D: https://github.com/vercel-labs/agent-skills 의 skills/web-design-guidelines
E: https://github.com/anthropics/skills 의 skills/frontend-design

새로 받으면 먼저 커밋을 확인하고 같은 커밋에서 일관되게 받아.
기존 설치본의 출처 커밋을 모르면 '기존 설치본, 원본 커밋 미확인'으로 적어.
파일 SHA-256을 Git 커밋 해시라고 쓰지 마.
네트워크 실패는 그 복구만 미완료로 남기고 이미 있는 정상 스킬은 유지해.

## 5. A·F — 제공본 사용, 새로 설계하지 않기

A는 skill-inputs/worklazy-systematic-debugging/SKILL.md를 사용해.
F는 skill-inputs/worklazy-scoped-verification/SKILL.md를 사용해.
F는 .agents와 .claude의 두 위치에 같은 바이트로 배치해.
A에 원본 Superpowers, TDD, verification-before-completion 연쇄 호출을 붙이지 마.
A·F를 짧게 요약하거나 다른 스킬로 바꾸지 마.
이미 같은 파일이 있으면 쓰기를 생략해. 다른 사용자 수정이 있으면 백업하고 차이를 보고해.
제공 최종본과 다른 수정이 요구사항을 실질적으로 바꾸면 그 대상만 보류해.

## 6. B — 브라우저 React용으로 범위 제한

B의 SKILL.md와 연결된 메타데이터의 사용 설명을 다음 범위로 맞춰.

'WorklazyTools의 변경된 브라우저 React 코드에서 상태·이벤트·재렌더링·클라이언트 번들·JavaScript 성능을 구현하거나 검토할 때 사용한다. 서버·Next.js 설계, 전역 리팩터링, 전 기능 검증에는 사용하지 않는다.'

기술 참고자료인 rules는 보존하되 SKILL.md에서 다음을 적용 목록에서 제외해.
- server-* 전체.
- async-api-routes와 서버 streaming을 전제로 하는 지침.
- Next.js pages/API Routes/Server Actions/RSC/SSR/hydration 전용 지침.
- next/dynamic을 이 프로젝트에 설치·사용하도록 하는 예제.
- SWR, better-all 등 새 라이브러리 설치를 요구하는 흐름.

bundle-dynamic-imports 같은 항목은 브라우저의 import() 또는 기존 React.lazy 적용을 검토하는 일반 원칙으로만 안내하고, Next.js 예제를 복사하지 않게 해.
이 과정에서 제품에 import()나 라이브러리를 실제 추가하지 마. 지금은 스킬만 수정한다.

유지할 범위는 관련 client 이벤트, rerender, 브라우저 rendering, js와 적용 가능한 async·bundle 지침이다.
관련 규칙 파일만 읽고, 전역 최적화·전체 회귀를 시작하지 않게 해.
설치된 React·브라우저·번들러가 지원하는지 확인하지 않은 API를 자동 도입하지 않도록 해.

B 폴더 안에 원본 전체 합본 AGENTS.md가 있으면
references/upstream-complete-guide.md로 옮기고 참조 경로를 수정해.
이 합본은 요청 시 참고하는 원본 자료이며 프로젝트 역할 규칙이 아니라고 표시해.
프로젝트 루트 AGENTS.md는 이 이동 대상이 아니다.
합본 전부를 시작할 때 읽으라는 지시는 제거하고 보조 자료·라이선스는 보존해.
기존 목적지 파일이 다르면 조용히 덮어쓰지 말고 해당 이동만 보류해.

## 7. C — Playwright 경로·산출물 수정

C의 scripts/playwright_cli.sh, references, 원본 고지를 보존해.
먼저 읽어서 경로가 어디에 고정됐는지 확인해.
원본 셸 래퍼에 고정 설치 경로가 없으면 그 스크립트 코드는 수정하지 마.
SKILL.md나 references의 실행 예에 있는
$CODEX_HOME/skills/playwright, ~/.codex/skills/playwright 고정 경로를
아래 프로젝트 기준 안내로 교체해. CODEX_HOME 전역 설정을 바꾸지 마.

SKILL.md에 넣을 경로 예시는 다음과 같다.
이 예시는 설치 후 실제 UI 검수가 승인됐을 때 쓰는 것이며 지금 실행하지 않는다.

    # 제품 저장소 또는 검수용 복사본 안에서 먼저 실행한다.
    ROOT="$(git rev-parse --show-toplevel)" || exit 1
    SKILL_DIR="$ROOT/.agents/skills/playwright"
    PWCLI="$SKILL_DIR/scripts/playwright_cli.sh"
    test -f "$PWCLI" || { printf '%s\n' 'Playwright 스킬 경로 확인 필요' >&2; exit 1; }
    RUN_DIR="$(mktemp -d "${TMPDIR:-/tmp}/worklazy-playwright.XXXXXXXX")" || exit 1
    cd "$RUN_DIR" || exit 1
    # 이후 필요한 브라우저 명령은 bash "$PWCLI" ... 형태로 호출한다.

같은 검수 작업에서는 RUN_DIR을 재사용하고, 새 셸에는 기록된 절대경로를 복원한다고 적어.
SKILL.md·references의 래퍼 실행 예시도 bash "$PWCLI" ... 형태로 통일해.
이를 위해 실행 권한을 전역 변경하거나 셸 래퍼 코드를 재작성하지 마.
스냅샷·트레이스·화면 출력은 이 임시 작업 공간에 남기게 해.
사용자가 명시한 검수용 복사본의 산출물 경로도 사용할 수 있지만 원본 제품 폴더에는 쓰지 않게 해.
output/playwright/를 제품 저장소에 반드시 만들라는 지시는 교체해.

원본의 npm install -g @playwright/cli@latest 자동 설치 안내는 제거하고,
도구가 없으면 '실행 준비 미완료'로 보고하며 별도 승인된 설치를 따르게 해.
래퍼의 npx는 패키지 다운로드를 유발할 수 있음을 표시해.
따라서 설치 확인으로 래퍼 --help를 실행하지 마. --help도 npx를 실행할 수 있다.
command -v 확인과 bash -n "$PWCLI"까지만 수행해.
문법 통과를 브라우저 실행 성공으로 보고하지 마.

스냅샷 후 요소 참조, DOM 변경 후 다시 스냅샷, 지정 경로만 재현하는 절차는 유지해.
기존 제품 테스트를 새 프레임워크로 옮기거나 Playwright 설정 파일을 생성하지 마.

## 8. D — UI 지침의 로컬 스냅샷과 증거 구분

D의 적용 범위를 '지정된 UI 코드·화면의 검토'로 제한해.
파일이 명시되지 않았으면 현재 지시서·diff에서 범위를 찾고, 그것도 없으면 대상을 미확인으로 남겨.
무조건 사용자에게 같은 범위를 다시 묻거나 전 사이트 감사로 확장하지 마.

현재 유효한 지침 스냅샷이 이미 있으면 재사용해.
없으면 다음 저장소의 command.md를 확인한 커밋으로 받아
references/web-interface-guidelines.md에 보관해.
https://github.com/vercel-labs/web-interface-guidelines

출처 URL·조회일·커밋 또는 원본 식별 가능 정보·파일 SHA-256을 기록해.
'매 검토마다 최신 지침을 다운로드'는
'저장된 지침을 사용하고 사용자 요청 또는 승인된 갱신 작업에서만 교체'로 바꿔.
스냅샷 다운로드 실패를 임의 요약 지침으로 대체하지 마. 그 단계만 미완료로 보고해.

관찰한 화면 증상, 코드 분석, 추정 원인을 구분하게 해.
파일·행 또는 캡처·화면·상태를 근거로 남기고, 열람하지 않은 화면은 미확인으로 적게 해.
URL 상태 공유 등의 일반 지침이 민감한 파일명·문서 내용·암호 외부 전송을 허용하지 않도록 명시해.
지정된 화면만 검토하며 코드 수정·광역 회귀는 시작하지 않게 해.

## 9. E — 승인된 디자인에만, 두 설치본 동일

E의 description과 본문에 다음 사용 조건을 맞춰.
- 사용자 요청이 있는 새 화면·새 디자인 검토, 승인된 디자인 변경에만 사용.
- 기존 UI의 정렬·버그 수정에는 자동 재설계하지 않음.
- Claude는 설계·검토, Sol은 승인된 구현만 담당.
- 공유 폴더에서 Gemini가 발견해도 제품 구현 권한은 생기지 않음.
- 기존 테마·토큰·컴포넌트·승인 시안을 우선 사용하고 새로운 팔레트·폰트를 강제하지 않음.
- 원본의 계획→구현 절차가 !계획! 조건과 제품 구현 승인을 대신하지 않음.
- 승인된 설계가 있으면 새 미학 기획부터 반복하지 않음.
- 디자인 검토를 이유로 무관한 전체 화면·전체 회귀를 실행하지 않음.

타이포그래피·간격·시각 계층·반응형·접근성·명확한 문구의 기술 지침은 유지해.
원본의 독창성 요구를 근거로 승인된 디자인을 바꾸도록 하는 충돌 문구는 정리해.
양쪽 E를 같은 수정본으로 맞추고 파일별 해시가 같은지 확인해.
기존 양쪽에 상충하는 사용자 변경이 있으면 백업 후 그 차이만 보고하고 임의 합치지 마.

## 10. 메타데이터·참조의 정적 확인

8개 대상에서 YAML frontmatter의 name과 description이 존재하고 이름이 기대값인지 확인해.
수정하지 않은 원본 license·저작권 고지를 보존해.
agents/openai.yaml 등 메타데이터가 있으면 default_prompt와 설명이 새 사용 범위와 충돌하지 않는지 확인해.
메타데이터의 설명만 필요 최소한으로 맞추고 도구 권한·새 hooks·MCP·동적 셸 실행을 추가하지 마.
없는 메타데이터 파일을 멋대로 만들어낼 필요는 없다.
다른 설치본을 덮어쓰는 전역 자동 활성화 설정도 변경하지 마.

SKILL.md와 실제로 사용하는 참고 파일의 상대경로가 존재하는지 확인해.
B 합본 이동, C 스크립트 경로, D 스냅샷 경로를 특별히 대조해.
E·F의 양쪽 설치본은 파일별 해시로 동일성을 확인해.
중복 이름은 프로젝트 스킬 경로에서 확인하되 다른 정상 스킬을 삭제하지 마.
전역 설치본은 이번 작업에서 수정하지 않는다. 실제로 보이는 충돌이 있으면 위치만 보고해.

## 11. 완료 보고와 종료

docs/skill-installation.md에 출처·수정 파일·설치 위치·백업 위치·확인 제한을 간결히 기록해.
원본 커밋을 모르는 것은 모른다고 적고 기록을 꾸미지 마.
설치 후 허용 경로 밖의 staged·unstaged·untracked 상태가 시작 시점과 달라지지 않았는지 확인해.
외부/허용 밖 변경이 발견되면 원인을 보고하고 사용자 변경을 자동으로 되돌리지 마.

최종 표는 아래 열을 사용해.
구분 | 실제 경로 | 파일·메타데이터 | 참조·경로 | 수정 내용 | 세션 인식 | 실행 준비

세션 인식은 현재 Gemini의 실제 제공 스킬 목록에서 확인한 것만 확인으로 적어.
단순히 SKILL.md를 읽을 수 있다는 것을 자동 인식 확인이라고 쓰지 마.
목록에 없으면 '파일 배치 완료, 새 세션 인식 미확인'으로 적어.
Codex·Claude를 실행하지 않았으므로 그 세션 인식은 '미확인—호출하지 않음'으로 적어.
C는 이번에 브라우저를 실행하지 않았으므로 실행 준비를 성공이라고 단정하지 마.

문서 5개 적용 여부, 스킬 8개 위치, 남은 차단 항목을 보고하면 종료해.
마지막 확인이라는 이유로 제품 테스트·다른 AI 호출·커밋·push를 추가하지 마.
