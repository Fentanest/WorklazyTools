# IE-F integration prototype

This local fork adds optional `IntegrationOptions` to `ImageEditor`, `EngineOptions`
and `openImageEditorDialog`. Unset options retain the existing network/export policy.

```tsx
<ImageEditor
  initialTool="redact"
  initialRedactMode="solid"
  fontResolver={() => 'local'}
  commitFormat="png"
  flattenTarget={{ width: 1600, height: 1200 }}
  onBeforeExport={async ({ format, path, hasConcealment }) => {
    // The host supplies its own translated confirmation UI.
    return hasConcealment ? 'flatten' : 'proceed';
  }}
  onDirtyChange={dirty => setUnsaved(dirty)}
  onHistoryChange={({ canUndo, canRedo, index, length }) => { /* host UI */ }}
  onError={error => { showErrorForCode(error.code); return true; }}
  suppressHandledErrorToast
  labels={KOREAN_LABELS}
/>
```

`onBeforeExport` receives `format` (six formats), `path` (`download`, `template`,
`commit`, or headless `api`), and conservative `hasConcealment`. It may return a
Promise. `cancel` throws `export-cancelled` in the engine; the controller handles
this silently without callbacks/downloads. A host returning `proceed` accepts the
editable original-source payload in SVG/JSON/templates.

`flatten` renders the **entire working scene** at `flattenTarget` (default working
surface dimensions), including all layers and background. It is independent of a
committed crop/artboard. A detached copy is rendered at the target resolution and
becomes a new scene with one PNG image tagged `aspId: base`. The editing scene is
preserved. Templates contain `concealmentEverApplied: false` and no history.
The separate `flattenScene(target)` engine API returns a disposable engine;
call `destroy()` when done. `exportTemplate()` is the asynchronous gated template
API. The legacy synchronous `exportScene()` works without a policy; with a policy
it throws before output, directing callers to `exportTemplate()` so an async gate
cannot be bypassed. `exportImage(format, quality, allowedFormats, path = 'api')`
always uses the gate. `commitFormat` forces the UI commit to a raster independently
of the download format allowlist. Downloading does not mark a document clean.

Concealment tags survive Fabric serialization/clone via registered custom properties.
The session flag survives undo/delete/template loads. Only a new source image clears
it. Templates reject remote/relative src/href at every nesting level before loading;
SVG image data URLs are also rejected to avoid nested remote resources. Data PNG,
JPEG, WebP and blob sources remain supported. Existing HEIC/background loaders stay
consumer supplied. Background replacement now inserts the cutout at the old z-index.

`fontResolver(family)` returns `local` or `google` and applies both to the screen
loader and SVG font embedding. `local` inserts no link and performs no font fetch.
The host is responsible for installing/declaring a local face; standalone SVG text
can fall back to another face on machines without it. Existing Google defaults stay.

`resolutionLimits` has independent positive finite numeric caps:

| Option | Omitted behavior | When supplied |
| --- | --- | --- |
| `inputMaxDimension` | 4096 longest edge for bounded import | Downsample decoded source |
| `workMaxPixels` | No extra cap | Reject work-surface allocation over area |
| `cropMaxPixels` | 4096² | Bound crop export area |
| `artboardMaxPixels` | No extra cap | Reject artboard area |
| `flattenMaxPixels` | No extra cap | Reject flatten output area |
| `limitUrlInputs` | false: URL/blob URL imports bypass bounded decoder | Fetch into bounded decoder |

Input caps reduce the stored image, not the decoder's initial allocation. Template
object payloads are not resampled by the image import cap. Fractional flatten targets
are rounded to positive integer pixels and checked both before and after rounding.
The existing `exportTarget` width-led scaling/height behavior is unchanged pending D6.

Dirty compares serialized document content (including crop/artboard) with a saved
baseline, independent of history length/index and the 50-entry history cap. New image
or loaded template establishes a baseline; a successful commit establishes the
pre-export baseline. Edits made while an async policy is pending remain dirty.
Crop/artboard changes are undoable and notify history/dirty listeners. A responsive
work-surface resize while clean rebases its fitted image without creating an edit.

Shortcuts/paste now require focus within the editor; hovering is insufficient.
Crop/redact expose scene-coordinate number fields (Left/Top/Width/Height). Tab to a
field and type values; crop still obeys its selected aspect and working-surface bounds.
The redraw button creates a new redaction marquee after applying the previous one.
Rotation buttons have explicit left/right accessible names. Existing responsive CSS
is unchanged.

`labels` maps exact English chrome strings to translated strings, with English fallback.
It covers visible text, registry labels, tooltips, placeholders, aria names, history
labels and error messages within each editor's context. `KOREAN_LABELS` is an initial
site-injection draft, not a complete Korean localization. `ERROR_MESSAGES` exports the
stable error-code dictionary. Return `true` from `onError` with
`suppressHandledErrorToast` to suppress the internal toast; cancellation is always quiet.

## Reproduction

```sh
npm ci --no-audit --no-fund
npm test
npm run build
npm run lint
npm run typecheck -w @ascentsparksoftware/react-image-editor
npm run e2e:fork
# Use an available Chromium if the default Playwright revision is not installed:
PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/path/to/chrome npm run e2e:fork
# Start the measurement host separately, then run fixed-scene metrics (Pillow + Poppler required).
npx vite --config tests/ief/vite.config.ts
npm run measure:fork
node tests/ief/bundle.mjs
# Override the upstream demo port when another task owns 4173:
PLAYWRIGHT_PORT=4185 npm run e2e
```

The six fixture definitions and input hashes were committed before evaluation in
`9ca2f30`. The background-removal scene remains unmeasured until IE-BG. Lossless
comparisons use RGBA; lossy RGB PSNR composites both reference and decoded output on
a white matte, since unassociated RGB under alpha=0 has no display meaning. The
metrics retain the raw RGB PSNR too. Acceptance thresholds and fixture inputs were
not changed after measurement.

The separately precommitted real-photo/screen supplement uses
`scenes-supplement.json` (commit `9cd2470`). Run it with `IEF_MANIFEST` and
`IEF_OUTPUT=.ief/supplement` for both measurement scripts. At the original JPEG-PDF baseline, its captured-screen JPEG
and JPEG-PDF cases measured 37.66–37.69 dB at quality .92 and **fail** the fixed
38 dB threshold; the synthetic original set passes. These are retained failures,
not a G3 acceptance. Existing Linux visual goldens also fail four cases on this
Chromium; an isolated upstream build produces pixel-identical actual images in
all four, so no golden files were updated.

PDF output now embeds a lossless PNG with jsPDF FAST compression; JPEG/WebP
download quality is unchanged. PDF preserves the PNG alpha mask and ignores the
lossy quality slider. Viewport popovers clamp only overflow, keep desktop preferred
rectangles, and close on Escape with focus restored to the opener.
