import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests/ief', testMatch: '*.spec.ts', timeout: 60000,
  use: {
    launchOptions: { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH }, baseURL: 'http://127.0.0.1:4184', viewport: { width: 390, height: 1000 } },
  webServer: { command: 'npx vite --config tests/ief/vite.config.ts', url: 'http://127.0.0.1:4184', reuseExistingServer: true },
});
