import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';

import { App } from './App';
import '@ascentsparksoftware/react-image-editor/styles.css';
import './styles.scss';

const container = document.getElementById('root');
if (!container) {
  throw new Error('demo: #root container missing from index.html');
}

createRoot(container).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
);
