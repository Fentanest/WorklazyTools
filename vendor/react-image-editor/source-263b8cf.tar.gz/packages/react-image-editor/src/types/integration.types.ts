import type { AspExportFormat, AspExportTarget, AspTool } from './editor.types';
export type FontResolver = (family: string) => 'local' | 'google';
export type ExportPath = 'download' | 'template' | 'commit' | 'api';
export interface BeforeExportContext {
  readonly format: AspExportFormat;
  readonly path: ExportPath;
  readonly hasConcealment: boolean;
}
export type ExportDecision = 'proceed' | 'flatten' | 'cancel';
export interface HistoryChange {
  readonly canUndo: boolean; readonly canRedo: boolean;
  readonly index: number; readonly length: number;
}
/** Caps are independent; omitted caps preserve upstream limits. Invalid caps throw. */
export interface ResolutionLimits {
  readonly inputMaxDimension?: number;
  readonly workMaxPixels?: number;
  readonly cropMaxPixels?: number;
  readonly artboardMaxPixels?: number;
  readonly flattenMaxPixels?: number;
  /** Fetch URL/blob sources into the bounded decoder too. Default false (upstream). */
  readonly limitUrlInputs?: boolean;
}
export interface IntegrationOptions {
  readonly onBeforeExport?: (context: BeforeExportContext) => ExportDecision | Promise<ExportDecision>;
  /** Entire scene output size for flattening; defaults to the working surface size. */
  readonly flattenTarget?: AspExportTarget;
  readonly commitFormat?: 'png' | 'jpeg' | 'webp';
  readonly fontResolver?: FontResolver;
  readonly resolutionLimits?: ResolutionLimits;
  readonly initialTool?: AspTool;
  readonly initialRedactMode?: 'solid' | 'blur' | 'pixelate';
  readonly onHistoryChange?: (state: HistoryChange) => void;
  readonly onDirtyChange?: (dirty: boolean) => void;
  readonly suppressHandledErrorToast?: boolean;
  /** Exact English message keys with partial overrides; absent keys use English. */
  readonly labels?: Readonly<Record<string, string>>;
}
