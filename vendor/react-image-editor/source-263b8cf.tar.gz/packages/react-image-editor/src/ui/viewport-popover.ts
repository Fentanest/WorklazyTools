import { useLayoutEffect, useRef } from 'react';

interface Rect { readonly left: number; readonly top: number; readonly width: number; readonly height: number }
interface Viewport { readonly left: number; readonly top: number; readonly width: number; readonly height: number }
/** Translation only: preserve the preferred placement when it already fits. */
export function popoverOffset(rect: Rect, viewport: Viewport, margin = 8): { x: number; y: number } {
  const left = viewport.left + margin, top = viewport.top + margin;
  const right = Math.max(left, viewport.left + viewport.width - margin - rect.width);
  const bottom = Math.max(top, viewport.top + viewport.height - margin - rect.height);
  return { x: Math.max(left, Math.min(rect.left, right)) - rect.left, y: Math.max(top, Math.min(rect.top, bottom)) - rect.top };
}

/** Keep DOM popovers inside the visual viewport without reordering focusable children. */
export function useViewportPopover<T extends HTMLElement>(open: boolean | string | null, onClose: () => void) {
  const ref = useRef<T>(null), close = useRef(onClose);
  useLayoutEffect(() => { close.current = onClose; });
  useLayoutEffect(() => {
    const node = ref.current;
    if (!open || !node) return;
    const opener = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const properties = ['translate', 'maxWidth', 'maxHeight', 'overflowY', 'boxSizing', 'position', 'left', 'top', 'right', 'bottom'] as const;
    const previous = Object.fromEntries(properties.map(key => [key, node.style[key]]));
    const restore = () => { for (const key of properties) node.style[key] = previous[key]; };
    const fit = () => {
      restore();
      const visual = window.visualViewport;
      const viewport = { left: visual?.offsetLeft ?? 0, top: visual?.offsetTop ?? 0, width: visual?.width ?? innerWidth, height: visual?.height ?? innerHeight };
      let rect = node.getBoundingClientRect();
      if (rect.width > viewport.width - 16) { node.style.boxSizing = 'border-box'; node.style.maxWidth = `${Math.max(0, viewport.width - 16)}px`; }
      if (rect.height > viewport.height - 16) { node.style.boxSizing = 'border-box'; node.style.maxHeight = `${Math.max(0, viewport.height - 16)}px`; node.style.overflowY = 'auto'; }
      rect = node.getBoundingClientRect();
      const offset = popoverOffset(rect, viewport);
      let x = offset.x, y = offset.y;
      // Absolute menus can fit the viewport yet be clipped by our canvas/panel.
      // Escape those clipping ancestors while retaining the same preferred rect.
      if (getComputedStyle(node).position !== 'fixed') {
        node.style.position = 'fixed'; node.style.left = '0px'; node.style.top = '0px';
        node.style.right = 'auto'; node.style.bottom = 'auto';
        const origin = node.getBoundingClientRect();
        x += rect.left - origin.left; y += rect.top - origin.top;
      }
      if (x || y) node.style.translate = `${x}px ${y}px`;
    };
    let closing = false;
    const escape = (event: KeyboardEvent) => {
      if (closing || event.key !== 'Escape' || !(node.contains(document.activeElement) || document.activeElement === opener || node.previousElementSibling === document.activeElement)) return;
      closing = true; event.preventDefault(); event.stopImmediatePropagation(); close.current();
      if (opener?.isConnected) opener.focus();
    };
    fit();
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(fit); observer?.observe(node);
    window.addEventListener('resize', fit); window.addEventListener('scroll', fit, true);
    window.visualViewport?.addEventListener('resize', fit); window.visualViewport?.addEventListener('scroll', fit);
    document.addEventListener('keydown', escape, true);
    return () => {
      observer?.disconnect(); restore(); window.removeEventListener('resize', fit); window.removeEventListener('scroll', fit, true);
      window.visualViewport?.removeEventListener('resize', fit); window.visualViewport?.removeEventListener('scroll', fit);
      document.removeEventListener('keydown', escape, true);
    };
  }, [open]);
  return ref;
}
