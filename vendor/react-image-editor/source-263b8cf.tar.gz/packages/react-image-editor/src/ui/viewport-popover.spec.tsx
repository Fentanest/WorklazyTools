import { useState } from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { popoverOffset, useViewportPopover } from './viewport-popover';

afterEach(() => vi.restoreAllMocks());
describe('viewport popovers', () => {
  it('keeps an already-visible desktop placement unchanged', () => {
    expect(popoverOffset({ left: 100, top: 80, width: 164, height: 134 }, { left: 0, top: 0, width: 1440, height: 900 })).toEqual({ x: 0, y: 0 });
  });
  it('clamps all viewport edges while retaining an eight-pixel margin', () => {
    const viewport = { left: 0, top: 0, width: 320, height: 640 };
    expect(popoverOffset({ left: 307, top: 610, width: 164, height: 134 }, viewport)).toEqual({ x: -159, y: -112 });
    expect(popoverOffset({ left: -100, top: -30, width: 164, height: 134 }, viewport)).toEqual({ x: 108, y: 38 });
  });
  it('uses visual viewport offsets when zoomed or panned', () => {
    expect(popoverOffset({ left: 0, top: 0, width: 100, height: 100 }, { left: 30, top: 40, width: 320, height: 400 })).toEqual({ x: 38, y: 48 });
  });
  it('closes on Escape, restores the opener, and keeps Escape out of the editor shortcut handler', () => {
    function Fixture() {
      const [open, setOpen] = useState(false);
      const ref = useViewportPopover<HTMLDivElement>(open, () => setOpen(false));
      return <><button onClick={() => setOpen(true)}>Open</button>{open && <div ref={ref} role="menu"><button role="menuitem">Action</button></div>}</>;
    }
    render(<Fixture />); const opener = screen.getByRole('button', { name: 'Open' }); opener.focus(); fireEvent.click(opener);
    const action = screen.getByRole('menuitem'); action.focus(); const shortcut = vi.fn(); document.addEventListener('keydown', shortcut);
    fireEvent.keyDown(action, { key: 'Escape' });
    expect(screen.queryByRole('menu')).toBeNull(); expect(document.activeElement).toBe(opener); expect(shortcut).not.toHaveBeenCalled();
    document.removeEventListener('keydown', shortcut);
  });
});
