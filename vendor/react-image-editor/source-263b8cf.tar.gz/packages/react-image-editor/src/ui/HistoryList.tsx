import { useLocalize } from '../i18n';
import { useState, type ReactElement } from 'react';

import { type HistoryStep } from '../engine/delta-history';
import { AspIcon } from '../icons/AspIcon';

export interface AspHistoryListProps {
  readonly entries: readonly HistoryStep[];
  readonly currentIndex: number;
}

/**
 * The History panel (bottom of the options column). Presentational: shows the
 * engine's edit entries, highlighting the current one and dimming any redo
 * branch ahead of the cursor. The user can collapse it via the header chevron.
 */
export function AspHistoryList({ entries, currentIndex }: AspHistoryListProps): ReactElement {
  const localize = useLocalize();
  const [collapsed, setCollapsed] = useState(false);

  return localize((
    <div className="asp-history-list">
      <button
        type="button"
        className="asp-history__head"
        aria-expanded={!collapsed}
        onClick={() => setCollapsed((v) => !v)}
      >
        <span className="asp-history__title">History</span>
        <AspIcon name={collapsed ? 'plus' : 'minus'} size={14} />
      </button>
      {!collapsed && (
        <div className="asp-history__scroll">
          {entries.map((entry, index) => (
            <div
              key={index}
              className={[
                'asp-history__row',
                index === currentIndex ? 'asp-history__row--current' : '',
                index > currentIndex ? 'asp-history__row--future' : '',
              ]
                .filter(Boolean)
                .join(' ')}
            >
              <AspIcon name="dot" size={16} />
              <span className="asp-history__label">{entry.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  ));
}
