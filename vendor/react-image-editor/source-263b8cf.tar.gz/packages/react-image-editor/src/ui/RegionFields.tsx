import { useEffect, useState } from 'react';
import type { EditorController } from '../controller/editor-controller';
import { useLabels } from '../i18n';
export function RegionFields({ controller }: { controller: EditorController }) {
  const t = useLabels();
  const engine = controller.currentEngine;
  const [region, setRegion] = useState(() => engine?.getMarquee() ?? null);
  useEffect(() => {
    const timer = setInterval(() => {
      const next = engine?.getMarquee() ?? null;
      setRegion(old => JSON.stringify(old) === JSON.stringify(next) ? old : next);
    }, 200);
    return () => clearInterval(timer);
  }, [engine]);
  if (!region) return <button type="button" className="asp-btn-line" onClick={() => { engine?.addRedactionMarquee(); setRegion(engine?.getMarquee() ?? null); }}>{t('Create region')}</button>;
  return <fieldset style={{ margin: 8, minWidth: 0 }}><legend>{t('Region')}</legend>
    {(['left', 'top', 'width', 'height'] as const).map(key => <label key={key} style={{ display: 'block' }}>
      {t(key[0].toUpperCase() + key.slice(1))}<input type="number" aria-label={t(key[0].toUpperCase() + key.slice(1))}
        style={{ width: 80 }} step={1} value={Math.round(region[key])} onChange={event => {
          const next = { ...region, [key]: Number(event.target.value) };
          engine?.setMarquee(next); setRegion(engine?.getMarquee() ?? next);
        }} />
    </label>)}
  </fieldset>;
}
