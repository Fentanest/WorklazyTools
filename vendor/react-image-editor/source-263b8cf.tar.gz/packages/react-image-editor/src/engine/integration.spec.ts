import { describe, expect, it, vi } from 'vitest';
import { assertLocalTemplate, checkPixels, hasConcealment, validateLimits } from './integration';
import { ensureFontLoaded } from '../fonts/fonts';
import { embedFontsInSvg } from './svg-fonts';
import { localizeTree, KOREAN_LABELS } from '../i18n';
import { createElement } from 'react';

describe('concealment boundary', () => {
  it('detects nested groups, legacy roles and explicit markers', () => {
    expect(hasConcealment({ objects: [{ objects: [{ aspConcealment: true }] }] })).toBe(true);
    expect(hasConcealment({ objects: [{ aspRole: 'redaction' }] })).toBe(true);
    expect(hasConcealment({ aspConcealment: false, aspRole: 'base' })).toBe(false);
  });
  it('rejects remote nested image/background resources before loading', () => {
    for (const src of ['https://example.test/a.png', '//example.test/a.png', '/a.png', 'javascript:alert(1)', 'data:image/svg+xml,<svg/>']) {
      expect(() => assertLocalTemplate({ snapshot: { json: { objects: [{ objects: [{ src }] }] } } })).toThrow();
    }
    expect(() => assertLocalTemplate({ objects: [{ src: 'data:image/png;base64,AA==' }, { src: 'blob:http://localhost/id' }] })).not.toThrow();
  });
});
describe('independent resolution limits', () => {
  it('rejects invalid limits and out of bounds allocation requests', () => {
    for (const value of [0, -1, Infinity, NaN]) expect(() => validateLimits({ inputMaxDimension: value })).toThrow();
    expect(() => checkPixels(100, 100, 9999)).toThrow();
    expect(() => checkPixels(100, 100, 10000)).not.toThrow();
    expect(() => checkPixels(8000, 3000)).not.toThrow();
  });
});
describe('local font policy', () => {
  it('neither inserts links nor invokes SVG fetch', async () => {
    const before = document.querySelectorAll('link').length;
    const resolver = () => 'local' as const;
    await ensureFontLoaded('Arial', resolver);
    const fetch = vi.fn();
    expect(await embedFontsInSvg('<svg/>', ['Arial', 'Inter'], fetch, resolver)).toBe('<svg/>');
    expect(fetch).not.toHaveBeenCalled();
    expect(document.querySelectorAll('link')).toHaveLength(before);
  });
});
describe('partial chrome labels', () => {
  it('translates nested chrome text and accessible names with English fallback', () => {
    const original = createElement('button', { title: 'Rotate left', 'aria-label': 'Rotate left' }, 'Crop');
    const result = localizeTree(original, KOREAN_LABELS);
    expect(result.props.title).toBe('왼쪽으로 회전');
    expect((result.props as {children?: unknown}).children).toBe('자르기');
    expect(localizeTree('Unspecified', KOREAN_LABELS)).toBe('Unspecified');
  });
});
