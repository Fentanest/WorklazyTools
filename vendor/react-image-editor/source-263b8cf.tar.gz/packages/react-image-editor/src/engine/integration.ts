import type { ResolutionLimits } from '../types/integration.types';
export class EditorOperationError extends Error {
  constructor(readonly code: string, message: string) { super(message); }
}
export function hasConcealment(value: unknown): boolean {
  if (!value || typeof value !== 'object') return false;
  if (Array.isArray(value)) return value.some(hasConcealment);
  const object = value as Record<string, unknown>;
  return object.aspConcealment === true || object.aspRole === 'redaction' ||
    Object.values(object).some(hasConcealment);
}
/** Reject before Fabric can initiate any image requests, including nested resources. */
export function assertLocalTemplate(value: unknown): void {
  if (!value || typeof value !== 'object') return;
  for (const [key, child] of Object.entries(value)) {
    if ((key === 'src' || key === 'href' || key === 'xlink:href') && typeof child === 'string' &&
        !/^(data:|blob:)/i.test(child)) {
      throw new EditorOperationError('template-remote-source', 'Templates may only contain data: or blob: sources.');
    }
    // SVG image payloads can themselves carry remote resources; forbid SVG template images.
    if (key === 'src' && typeof child === 'string' && /^data:image\/svg/i.test(child)) {
      throw new EditorOperationError('template-remote-source', 'SVG template images must be rasterized first.');
    }
    assertLocalTemplate(child);
  }
}
export function validateLimits(limits?: ResolutionLimits): void {
  for (const [key, value] of Object.entries(limits ?? {})) {
    if (key !== 'limitUrlInputs' && (typeof value !== 'number' || !Number.isFinite(value) || value < 1))
      throw new EditorOperationError('resolution-limit', 'Resolution limits must be positive finite numbers.');
  }
}
export function checkPixels(width: number, height: number, max?: number): void {
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0 ||
      (max !== undefined && width * height > max))
    throw new EditorOperationError('resolution-limit', 'The requested resolution exceeds the configured limit.');
}
