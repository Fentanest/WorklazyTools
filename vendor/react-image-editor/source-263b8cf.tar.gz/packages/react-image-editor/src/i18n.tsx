import { createContext, useContext, isValidElement, cloneElement } from 'react';
export const LabelsContext = createContext<Readonly<Record<string, string>>>({});
export function useLabels(): (english: string) => string {
  const labels = useContext(LabelsContext);
  return (english) => labels[english] ?? english;
}
export const ERROR_MESSAGES: Readonly<Record<string, string>> = {
  'engine-init-failed': 'Could not initialize the editor.',
  'load-failed': 'Could not load the image.',
  'export-failed': 'Could not export the image.',
  'template-save-failed': 'Could not save the template.',
  'template-load-failed': 'Could not load the template.',
  'template-remote-source': 'Templates may only contain data: or blob: sources.',
  'resolution-limit': 'The requested resolution exceeds the configured limit.',
  'image-add-failed': 'Could not add the image.',
  'ai-no-image': 'No image to process.',
  'ai-failed': 'Could not process the image.',
  'magic-erase-failed': 'Could not erase the selected area.',
  'redaction-failed': 'Could not conceal the selected area.',
  'font-load-failed': 'Could not load the font.',
  'export-policy-invalid': 'Invalid export decision.',
};
/** Korean injection draft. Additional English keys may be overridden by the host. */
export const KOREAN_LABELS: Readonly<Record<string, string>> = {
  'Crop': '자르기', 'Redact': '가리기', 'Adjust': '색상 조정', 'Color': '색상',
  'Rotate': '회전', 'Text': '텍스트', 'Draw': '그리기', 'Export': '내보내기',
  'Apply': '적용', 'Save': '저장', 'Cancel': '취소', 'Close': '닫기',
  'Rotate left': '왼쪽으로 회전', 'Rotate right': '오른쪽으로 회전',
  'Undo': '실행 취소', 'Redo': '다시 실행', 'History': '편집 기록', 'Edit history': '편집 기록', 'Close history': '기록 닫기',
  'Apply crop': '자르기 적용', 'Reset crop': '자르기 초기화',
  'Apply redaction': '가리기 적용', 'Pixelate': '모자이크', 'Blur': '흐리게', 'Solid': '단색',
  'Download image': '이미지 다운로드', 'Save template': '템플릿 저장',
  'Load template': '템플릿 불러오기', 'Edit image': '이미지 편집',
  'Region': '영역', 'Left': '왼쪽 위치', 'Top': '위쪽 위치', 'Width': '너비', 'Height': '높이',
  'Opened editor': '편집기 열기', 'Opened image': '이미지 열기', 'Loaded template': '템플릿 불러오기',
  'Could not export the image.': '이미지를 내보내지 못했습니다.',
  'Could not load the image.': '이미지를 불러오지 못했습니다.',
  'Could not load the template.': '템플릿을 불러오지 못했습니다.',
  'Templates may only contain data: or blob: sources.': '템플릿은 data: 또는 blob: 이미지만 포함할 수 있습니다.',
};

/** Translate rendered chrome strings, including dynamic registry/history labels. */
export function localizeTree<T>(value: T, labels: Readonly<Record<string, string>>): T {
  if (typeof value === 'string') {
    const key = value.trim();
    return (labels[key] === undefined ? value : value.replace(key, () => labels[key])) as T;
  }
  if (Array.isArray(value)) return value.map(child => localizeTree(child, labels)) as T;
  if (!isValidElement(value)) return value;
  const props = value.props as Record<string, unknown>;
  const translated: Record<string, unknown> = {};
  for (const key of ['title', 'aria-label', 'placeholder', 'alt']) {
    if (typeof props[key] === 'string') translated[key] = localizeTree(props[key], labels);
  }
  if ('children' in props) translated.children = localizeTree(props.children, labels);
  return cloneElement(value, translated) as T;
}
export function useLocalize(): <T>(value: T) => T {
  const labels = useContext(LabelsContext);
  return value => localizeTree(value, labels);
}
