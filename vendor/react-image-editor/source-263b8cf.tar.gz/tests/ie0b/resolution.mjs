import fs from 'node:fs';
import { chromium } from '@playwright/test';
const output=process.env.IE0B_OUTPUT??'.ief/ie0b';fs.mkdirSync(output+'/raw',{recursive:true});
const browser=await chromium.launch({executablePath:'/home/better0101/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome',args:['--enable-precise-memory-info']});
const page=await browser.newPage({viewport:{width:1440,height:1000}}),cdp=await page.context().newCDPSession(page);
await page.goto('http://127.0.0.1:4194');await page.waitForFunction(()=>window.ready);
const rows=[],setups=[];let active=false,samples=[];
const timer=setInterval(async()=>{if(!active)return;try{samples.push(await cdp.send('Runtime.getHeapUsage'))}catch{}},100);
function save(){fs.writeFileSync(output+'/raw/resolution-matrix.json',JSON.stringify({definitions:{A:'default caps; explicit flatten target=decoded base dimensions',B:'input8192/crop8192²/flatten8192²/url-bounded; explicit flatten target=decoded base dimensions',stage:[1000,700],heap:'Observed CDP JS heap, excludes native canvas/WASM/GPU memory'},setups,rows},null,2))}
try{
for(const [width,height]of[[6000,4000],[4000,3000],[8000,3000]])for(const inputType of['image/png','image/jpeg','image/webp']){
 await page.evaluate(async a=>{window.matrixSource=await window.makeFixture(a.width,a.height,a.inputType)},{width,height,inputType});
 for(const policy of['A','B']){
  await cdp.send('HeapProfiler.collectGarbage');
  const setup=await page.evaluate(async({policy,width,height,inputType})=>{
   const limits={inputMaxDimension:8192,cropMaxPixels:8192*8192,flattenMaxPixels:8192*8192,limitUrlInputs:true};
   const e=await window.newEngine(policy==='B'?{resolutionLimits:limits}:{}),start=performance.now();await e.loadImage(window.matrixSource);
   const base=e.canvas.getObjects().find(o=>o.get('aspId')==='base');window.matrixTarget={width:base.width,height:base.height};
   return{policy,input:[width,height],inputType,base:[base.width,base.height],stage:[e.canvas.width,e.canvas.height],sourceBytes:window.matrixSource.size,loadMs:performance.now()-start,flattenTarget:window.matrixTarget}
  },{policy,width,height,inputType});setups.push(setup);console.log('setup',JSON.stringify(setup));
  for(const path of['none','crop-1:1','artboard-source-size']){
   await page.evaluate(({path,width,height})=>{const e=window.engine;e.clearCropRegion();e.setArtboard(null);if(path==='crop-1:1'){e.beginCrop(1);e.applyCropRegion()}if(path==='artboard-source-size')e.setArtboard({width,height})},{path,width,height});
   for(const flattened of[false,true])for(const format of['png','jpeg','webp','pdf']){
    await cdp.send('HeapProfiler.collectGarbage');samples=[];const before=await cdp.send('Runtime.getHeapUsage');active=true;
    const result=await page.evaluate(async({format,flattened,policy})=>{
     const e=window.engine;e.configureIntegration({fontResolver:()=> 'local',...(policy==='B'?{resolutionLimits:{inputMaxDimension:8192,cropMaxPixels:8192*8192,flattenMaxPixels:8192*8192,limitUrlInputs:true}}:{}),flattenTarget:window.matrixTarget,onBeforeExport:()=>flattened?'flatten':'proceed'});
     const start=performance.now();try{const blob=await e.exportImage(format,92,[format]);let dimensions;
      if(format==='pdf'){const s=new TextDecoder('latin1').decode(await blob.arrayBuffer()),m=s.match(/\/Subtype\s*\/Image[\s\S]*?\/Width\s+(\d+)\s*\/Height\s+(\d+)/);dimensions=m?[Number(m[1]),Number(m[2])]:null}
      else{const b=await createImageBitmap(blob);dimensions=[b.width,b.height];b.close()}
      return{ok:true,dimensions,bytes:blob.size,exportMs:performance.now()-start}
     }catch(error){return{ok:false,error:String(error),exportMs:performance.now()-start}}
    },{format,flattened,policy});active=false;const after=await cdp.send('Runtime.getHeapUsage'),observed=[before,after,...samples];
    const row={...setup,path,flattened,format,...result,heapBefore:before,heapAfter:after,maxObservedJsHeap:Math.max(...observed.map(x=>x.usedSize)),heapSamples:observed.length};rows.push(row);save();console.log(JSON.stringify({policy,inputType,input:[width,height],path,flattened,format,dimensions:row.dimensions,ms:row.exportMs,heap:row.maxObservedJsHeap,ok:row.ok}));
   }
  }
 }
}
}finally{clearInterval(timer);save();await browser.close()}
console.log(JSON.stringify({rows:rows.length,failures:rows.filter(r=>!r.ok).length}));
