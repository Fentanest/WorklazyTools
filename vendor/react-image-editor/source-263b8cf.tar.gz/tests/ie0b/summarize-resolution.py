from pathlib import Path
import json,statistics
root=Path('.ief/ie0b');data=json.loads((root/'raw/resolution-matrix.json').read_text());rows=data['rows'];assert len(rows)==432 and all(r['ok']for r in rows)
summary={'count':len(rows),'failures':sum(not r['ok']for r in rows),'policies':{},'matrix':[],'shapeNotes':['Flatten rows explicitly set target to decoded-base dimensions. This is a benchmark host policy, not the library default.','Full working scene is 1000x700; a nonmatching explicit target stretches that scene. Extra measurements include aspect-preserved scene targets and default flatten1000x700.','Observed JS heap excludes native canvas, image decode, GPU and WASM memory.']}
for policy in ['A','B']:
 q=[r for r in rows if r['policy']==policy];summary['policies'][policy]={'exports':len(q),'medianMs':statistics.median(r['exportMs']for r in q),'maxMs':max(r['exportMs']for r in q),'maxObservedJsHeap':max(r['maxObservedJsHeap']for r in q),'medianLoadMs':statistics.median(s['loadMs']for s in data['setups']if s['policy']==policy)}
 for dims in [[6000,4000],[4000,3000],[8000,3000]]:
  for path in ['none','crop-1:1','artboard-source-size']:
   for flattened in [False,True]:
    group=[r for r in q if r['input']==dims and r['path']==path and r['flattened']==flattened];dimensions=sorted(set(tuple(r['dimensions'])for r in group));summary['matrix'].append({'policy':policy,'input':dims,'path':path,'flattened':flattened,'base':group[0]['base'],'outputs':[list(d)for d in dimensions],'n':len(group),'medianMs':statistics.median(r['exportMs']for r in group),'minMs':min(r['exportMs']for r in group),'maxMs':max(r['exportMs']for r in group),'maxObservedJsHeap':max(r['maxObservedJsHeap']for r in group)})
(root/'raw/resolution-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['policies'],indent=2))
