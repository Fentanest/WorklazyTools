import { chromium } from '@playwright/test';
import fs from 'node:fs';
import crypto from 'node:crypto';
const out='.ief/ie0b/codec';fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({executablePath:'/home/better0101/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome'});const page=await browser.newPage();await page.goto('http://127.0.0.1:4194');await page.waitForFunction(()=>window.ready);
const facts=[];
try{
 for(const scene of['actual-screen-solid','actual-screen-pixelate']){
  const source=fs.readFileSync(`.ief/supplement/exports/${scene}.reference.png`),data='data:image/png;base64,'+source.toString('base64');
  const result=await page.evaluate(async data=>{
   const response=await fetch(data),bitmap=await createImageBitmap(await response.blob()),canvas=document.createElement('canvas');canvas.width=bitmap.width;canvas.height=bitmap.height;
   const x=canvas.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,canvas.width,canvas.height);x.drawImage(bitmap,0,0);bitmap.close();
   const files={};for(const quality of[.92,.95,.98,1])files['jpeg-q'+String(quality).replace('.','')]=canvas.toDataURL('image/jpeg',quality).split(',')[1];
   const e=await window.newEngine({width:canvas.width,height:canvas.height});const moduleUrl=e.exportPdf.toString().match(/import\(["']([^"']*jspdf[^"']*)["']\)/)?.[1];if(!moduleUrl)throw Error('Cannot locate the already-loaded jsPDF dependency');
   const{jsPDF}=await import(moduleUrl);for(const compression of ['NONE','FAST','SLOW']){const pdf=new jsPDF({orientation:canvas.width>=canvas.height?'landscape':'portrait',unit:'px',format:[canvas.width,canvas.height]});pdf.addImage(data,'PNG',0,0,canvas.width,canvas.height,undefined,compression);const blob=pdf.output('blob'),bytes=new Uint8Array(await blob.arrayBuffer());let s='';for(const byte of bytes)s+=String.fromCharCode(byte);files['pdf-png-'+compression.toLowerCase()]=btoa(s);}
   return{files,dimensions:[canvas.width,canvas.height],pdfModule:moduleUrl};
  },data);
  fs.writeFileSync(`${out}/${scene}.reference.png`,source);
  for(const[name,value]of Object.entries(result.files))fs.writeFileSync(`${out}/${scene}.${name.startsWith('pdf-png')?name+'.pdf':name+'.jpg'}`,Buffer.from(value,'base64'));
  facts.push({scene,referenceSHA256:crypto.createHash('sha256').update(source).digest('hex'),dimensions:result.dimensions,pdfModule:result.pdfModule});
 }
 fs.writeFileSync(out+'/facts.json',JSON.stringify(facts,null,2));
}finally{await browser.close()}
