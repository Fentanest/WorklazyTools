from pathlib import Path
from PIL import Image
import numpy as np,json,re,base64,subprocess,math
root=Path('.ief/ie0b/bg-scene');criteria=json.loads(Path('tests/fixtures/redaction-export/scenes.json').read_text())['criteria'];rows=[]
facts=json.loads((root/'facts.json').read_text())['facts']
for fact in facts:
 name=fact.get('id',fact['order']);reference=Image.open(root/f'{name}.reference.png').convert('RGBA')
 for kind,src in [('svg',re.search(r'data:image/png;base64,([A-Za-z0-9+/=]+)',(root/f'{name}.svg').read_text())[1]),('json',json.loads((root/f'{name}.json').read_text())['objects'][0]['src'].split(',')[1]),('template',json.loads((root/f'{name}.template.json').read_text())['snapshot']['json']['objects'][0]['src'].split(',')[1])]:
  (root/f'{name}.{kind}-base.png').write_bytes(base64.b64decode(src))
 pdfLossless=b'/DCTDecode' not in (root/f'{name}.pdf').read_bytes()
 for extracted in root.glob(f'{name}.pdfimage-*.png'):extracted.unlink()
 subprocess.run(['pdfimages','-png',str(root/f'{name}.pdf'),str(root/f'{name}.pdfimage')],check=True)
 pdf=Image.open(root/f'{name}.pdfimage-000.png').convert('RGBA');mask=root/f'{name}.pdfimage-001.png'
 if mask.exists():pdf.putalpha(Image.open(mask).convert('L'))
 pdf.save(root/f'{name}.pdf-rgba.png')
 for format,file in [('png',f'{name}.png'),('jpeg',f'{name}.jpeg'),('webp',f'{name}.webp'),('pdf',f'{name}.pdf-rgba.png'),('svg',f'{name}.svg-base.png'),('json',f'{name}.json-base.png'),('template',f'{name}.template-base.png')]:
  image=Image.open(root/file).convert('RGBA');delta=np.abs(np.array(image).astype(int)-np.array(reference).astype(int)).max(axis=2);fraction=float(np.mean(delta<=1));maximum=int(delta.max());lossless=format in ['png','svg','json','template'] or(format=='pdf'and pdfLossless);row={'order':name,'format':format,'fractionChannelDeltaLE1':fraction,'maxChannelDelta':maximum}
  if lossless:row['aPass']=fraction>=.9999 and maximum<=8
  else:
   def white(im):bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);return np.asarray(bg.convert('RGB')).astype(float)
   mse=np.mean((white(image)-white(reference))**2);psnr=10*math.log10(255**2/mse)if mse else None;row['PSNRdB']=psnr;row['aPass']=psnr is None or psnr>=38
  sample=np.asarray(image)[172:288,142:498,:3].astype(int);difference=np.abs(sample-np.array([11,15,26])).max(axis=2);row['solidFractionDeltaLE6']=float(np.mean(difference<=6));row['solidMaxDelta']=int(difference.max());row['bPass']=bool(difference.max()==0 if lossless else np.mean(difference<=6)>=.995 and difference.max()<=16);rows.append(row)
 payloadPass=fact['unchanged']and fact['originalOccurrences']==[0,0,0]and fact['cutoutOccurrences']==[0,0,0]and fact['sourceCounts']==[1,1]and fact['jsonObjects']==fact['templateObjects']==1 and fact['templateFlag']==False and not fact['historyKeys'];fact['payloadPass']=payloadPass
summary={'rows':rows,'allPixelPass':all(x['aPass']and x['bPass']for x in rows),'facts':facts};(root/'metrics.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(rows,indent=2))
