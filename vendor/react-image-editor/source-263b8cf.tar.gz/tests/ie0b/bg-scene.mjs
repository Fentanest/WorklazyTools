import fs from 'node:fs';
import crypto from 'node:crypto';
import { chromium } from '@playwright/test';
const out='.ief/ie0b/bg-scene';fs.mkdirSync(out,{recursive:true});

const browser=await chromium.launch({executablePath:'/home/better0101/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome'});const page=await browser.newPage();const requests=[];page.on('request',r=>requests.push(r.url()));await page.goto('http://127.0.0.1:4194');await page.waitForFunction(()=>window.ready);
const facts=[];
try{
for(const specimen of [{label:'synthetic',file:'photo.png'},{label:'actual',file:'real-photo.png'}])for(const order of['background-then-solid','solid-then-background']){
 const input=fs.readFileSync('tests/fixtures/redaction-export/'+specimen.file),id=specimen.label+'-'+order;
 const result=await page.evaluate(async({src,order})=>{
  const e=await window.newEngine({width:640,height:480});await e.loadImage(src);const original=e.baseImage.getSrc();
  const redact=async()=>{e.addRedactionMarquee();e.setMarquee({left:140,top:170,width:360,height:120});await e.applyRedaction('solid')};
  if(order==='background-then-solid'){await e.removeImageBackground('replace');await redact()}else{await redact();await e.removeImageBackground('replace')}
  const cutout=e.baseImage.getSrc();const state=JSON.stringify(e.canvas.toObject());const reference=e.canvas.toCanvasElement(1).toDataURL('image/png');
  e.configureIntegration({fontResolver:()=> 'local',flattenTarget:{width:640,height:480},onBeforeExport:()=> 'flatten'});
  const files={};for(const format of['png','jpeg','webp','pdf','svg','json']){const blob=await e.exportImage(format,92,[format]);const bytes=new Uint8Array(await blob.arrayBuffer());let binary='';for(const b of bytes)binary+=String.fromCharCode(b);files[format]=btoa(binary)}
  files.template=btoa(unescape(encodeURIComponent(await e.exportTemplate())));
  const svg=atob(files.svg),json=atob(files.json),template=atob(files.template),parsed=JSON.parse(template);
  return{files,reference:reference.split(',')[1],cutout:cutout.split(',')[1],unchanged:state===JSON.stringify(e.canvas.toObject()),hasConcealment:e.hasConcealment,roles:e.canvas.getObjects().map(o=>({id:o.get('aspId'),role:o.get('aspRole')})),originalOccurrences:[svg,json,template].map(s=>s.split(original).length-1),cutoutOccurrences:[svg,json,template].map(s=>s.split(cutout).length-1),jsonObjects:JSON.parse(json).objects.length,templateObjects:parsed.snapshot.json.objects.length,templateFlag:parsed.concealmentEverApplied,historyKeys:/"(?:history|previousScene|originalSrc)"/.test(json+template),sourceCounts:[json,template].map(s=>(s.match(/"src":"(?:data:|blob:)/g)??[]).length),bgEvents:window.bgEvents};
 },{src:'data:image/png;base64,'+input.toString('base64'),order});
 for(const[k,v]of Object.entries(result.files))fs.writeFileSync(`${out}/${id}.${k==='template'?'template.json':k}`,Buffer.from(v,'base64'));
 fs.writeFileSync(`${out}/${id}.reference.png`,Buffer.from(result.reference,'base64'));fs.writeFileSync(`${out}/${id}.cutout.png`,Buffer.from(result.cutout,'base64'));
 const{files,reference,cutout,...fact}=result;facts.push({id,order,inputFile:specimen.file,inputSHA256:crypto.createHash('sha256').update(input).digest('hex'),...fact});
}
}finally{fs.writeFileSync(out+'/facts.json',JSON.stringify({criteriaSource:'tests/fixtures/redaction-export/scenes.json @9ca2f30, actual-photo supplement @9cd2470',facts,requests,externalRequests:requests.filter(s=>/^https?:/.test(s)&&!s.startsWith('http://127.0.0.1:4194/'))},null,2));await browser.close()}
