import{chromium}from'@playwright/test';import fs from'node:fs';
const browser=await chromium.launch({executablePath:'/home/better0101/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome'}),page=await browser.newPage();await page.goto('http://127.0.0.1:4194');await page.waitForFunction(()=>window.ready);const rows=[];
try{for(const [width,height]of[[6000,4000],[8000,3000]])for(const policy of['A','B']){
 const row=await page.evaluate(async({width,height,policy})=>{
  const limits=policy==='B'?{resolutionLimits:{inputMaxDimension:8192,cropMaxPixels:8192*8192,flattenMaxPixels:8192*8192,limitUrlInputs:true}}:{};
  const e=await window.newEngine(limits),blob=await window.makeFixture(width,height),url=URL.createObjectURL(blob);await e.loadImage(url);URL.revokeObjectURL(url);const source=e.baseImage;
  const sourceDimensions=[source.width,source.height];e.beginCrop(width/height);const bounds=source.getBoundingRect();e.setMarquee({left:bounds.left,top:bounds.top,width:bounds.width,height:bounds.height});e.applyCropRegion();
  const start=performance.now(),output=await e.exportImage('png',92,['png']),bitmap=await createImageBitmap(output),cropOutput=[bitmap.width,bitmap.height];bitmap.close();e.clearCropRegion();
  const ordinary=await e.flattenScene();const b=await ordinary.exportImage('png',92,['png']),bd=await createImageBitmap(b);const defaultFlatten=[bd.width,bd.height];bd.close();await ordinary.destroy();
  const scale=1/source.scaleX,target={width:Math.round(1000*scale),height:Math.round(700*scale)};
  const merged=await e.flattenScene(target),full=await merged.exportImage('png',92,['png']),fd=await createImageBitmap(full);const aspectPreservedFlatten=[fd.width,fd.height];fd.close();await merged.destroy();
  return{policy,input:[width,height],sourceKind:'blob URL',sourceDimensions,cropOutput,defaultFlatten,aspectPreservedFlatten,aspectPreservedTarget:target,elapsedMs:performance.now()-start}
 },{width,height,policy});rows.push(row);console.log(JSON.stringify(row));}
}finally{fs.writeFileSync('.ief/ie0b/raw/resolution-extra.json',JSON.stringify(rows,null,2));await browser.close()}
