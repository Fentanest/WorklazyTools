from PIL import Image, JpegImagePlugin, features
from pathlib import Path
import numpy as np,subprocess,json,math
root=Path('.ief/ie0b/codec');rows=[]
for scene in ['actual-screen-solid','actual-screen-pixelate']:
 reference=Image.open(root/f'{scene}.reference.png').convert('RGBA');white=Image.new('RGBA',reference.size,'white');white.alpha_composite(reference);rgb=white.convert('RGB');ref=np.array(rgb).astype(float)
 rgb.save(root/f'{scene}.pillow-q092-444.jpg',quality=92,subsampling=0)
 for path in sorted(root.glob(scene+'*.jpg')):
  im=Image.open(path);a=np.array(im.convert('RGB')).astype(float);mse=np.mean((a-ref)**2);psnr=10*math.log10(255**2/mse) if mse else None
  rows.append({'scene':scene,'file':path.name,'format':'jpeg','bytes':path.stat().st_size,'PSNRdB':psnr,'meets38dB':psnr is None or psnr>=38,'subsampling':JpegImagePlugin.get_sampling(im),'quality92Contract':('q092' in path.name),'jpegLibrary':features.version_codec('jpg')})
 for path in sorted(root.glob(scene+'.pdf-png*.pdf')):
  prefix=root/path.stem;subprocess.run(['pdfimages','-png',str(path),str(prefix)],check=True)
  im=Image.open(str(prefix)+'-000.png').convert('RGBA');maskpath=Path(str(prefix)+'-001.png')
  if maskpath.exists():im.putalpha(Image.open(maskpath).convert('L'))
  diff=np.abs(np.array(im).astype(int)-np.array(reference).astype(int)).max(axis=2);fraction=float(np.mean(diff<=1));maximum=int(diff.max());rows.append({'scene':scene,'file':path.name,'format':'pdf-png','bytes':path.stat().st_size,'fractionChannelDeltaLE1':fraction,'maxChannelDelta':maximum,'meetsLossless':fraction>=.9999 and maximum<=8,'alphaMaskPresent':maskpath.exists()})
(root/'metrics.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
