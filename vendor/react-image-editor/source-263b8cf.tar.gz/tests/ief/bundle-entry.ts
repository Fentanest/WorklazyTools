export { ImageEditor } from '../../packages/react-image-editor/src/index';
import '../../packages/react-image-editor/dist/styles.css';
