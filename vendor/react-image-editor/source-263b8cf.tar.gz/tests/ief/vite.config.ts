import { defineConfig } from 'vite';
export default defineConfig({ root: import.meta.dirname, server: { host: '127.0.0.1', port: 4184, strictPort: true, fs: { allow: [import.meta.dirname + '/../..'] } } });
