// Run alongside the 4184 fixture host. Freeze inputs; measure only JPEG95 vs JPEG92 and unchanged WebP92.
import { chromium } from '@playwright/test';
import fs from 'node:fs';
import crypto from 'node:crypto';
const out = '.ief/d6-jpeg'; fs.mkdirSync(out, { recursive: true });
const manifest = JSON.parse(fs.readFileSync('tests/fixtures/redaction-export/scenes-supplement.json'));
const scenes = manifest.scenes.filter(s => !s.requiresIEBG);
for (const s of scenes) {
  const bytes = fs.readFileSync(`tests/fixtures/redaction-export/${s.input}`);
  if (crypto.createHash('sha256').update(bytes).digest('hex') !== s.sha256) throw new Error('fixture hash mismatch');
  s.src = `data:image/png;base64,${bytes.toString('base64')}`;
}
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH });
try {
  const page = await browser.newPage(); await page.goto('http://127.0.0.1:4184');
  await page.waitForFunction(() => window.ready);
  await page.evaluate(() => window.mount({ jpegExportQuality: 95, exportQuality: 92, exportFormats: ['jpeg', 'webp'], fontResolver: () => 'local' }));
  await page.waitForFunction(() => window.events.some(e => e.event === 'loaded'));
  const quality = await page.evaluate(() => {
    const c = window.controller, jpeg = c.getSnapshot().exportQ;
    c.setExportFormat('webp'); const webp = c.getSnapshot().exportQ;
    return { jpeg, webp };
  });
  if (quality.jpeg !== 95 || quality.webp !== 92) throw new Error('UI quality mismatch');
  for (const scene of scenes) {
    const result = await page.evaluate(async ({ scene, region, target, quality }) => {
      const w = window, e = await w.newEngine({ fontResolver: () => 'local', flattenTarget: target, onBeforeExport: () => 'flatten' });
      await e.loadImage(scene.src); e.addRedactionMarquee(); e.setMarquee(region); await e.applyRedaction(scene.mode);
      if (scene.nested) {
        const object = e.canvas.getObjects().find(o => o.get('aspRole') === 'redaction');
        e.canvas.remove(object); e.canvas.add(new w.api.fabric.Group([new w.api.fabric.Group([object])]));
      }
      const reference = e.canvas.toCanvasElement(1).toDataURL('image/png').split(',')[1];
      const files = { 'reference.png': reference };
      for (const [name, format, q] of [['q95.jpeg', 'jpeg', quality.jpeg], ['q92.jpeg', 'jpeg', 92], ['q92.webp', 'webp', quality.webp]]) {
        const bytes = new Uint8Array(await (await e.exportImage(format, q, [format])).arrayBuffer());
        let data = ''; for (const byte of bytes) data += String.fromCharCode(byte);
        files[name] = btoa(data);
      }
      return files;
    }, { scene, region: manifest.region, target: manifest.outputResolution, quality });
    for (const [name, data] of Object.entries(result)) fs.writeFileSync(`${out}/${scene.id}.${name}`, Buffer.from(data, 'base64'));
  }
  fs.writeFileSync(`${out}/facts.json`, JSON.stringify({ chromium: browser.version(), quality, criteria: manifest.criteria.lossy, scenes: scenes.map(({ src, ...s }) => s) }, null, 2));
  console.log(`Measured ${scenes.length} scenes at JPEG ${quality.jpeg}, WebP ${quality.webp}`);
} finally { await browser.close(); }
