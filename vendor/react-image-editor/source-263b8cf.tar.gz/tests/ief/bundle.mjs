import { build } from 'esbuild';
import fs from 'node:fs';
import { gzipSync } from 'node:zlib';
const result = await build({ entryPoints: ['tests/ief/bundle-entry.ts'], outdir: '.ief/bundle', bundle: true, minify: true, splitting: true, format: 'esm', target: 'es2022', jsx: 'automatic', external: ['react', 'react-dom', 'react/jsx-runtime', 'react-dom/client'], metafile: true });
const rows = Object.entries(result.metafile.outputs).map(([name, value]) => ({ name, bytes: value.bytes, gzipBytes: gzipSync(fs.readFileSync(name), { level: 9 }).length, imports: value.imports }));
fs.writeFileSync('.ief/raw/bundle-sizes.json', JSON.stringify(rows, null, 2));
console.log(rows);
