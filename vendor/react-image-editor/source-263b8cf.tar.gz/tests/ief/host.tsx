import React from 'react';
import { createRoot } from 'react-dom/client';
import { ImageEditor, EditorEngine, KOREAN_LABELS } from '../../packages/react-image-editor/src';
import { ensureFontLoaded } from '../../packages/react-image-editor/src/fonts/fonts';
import { EditorController } from '../../packages/react-image-editor/src/controller/editor-controller';
import * as fabric from 'fabric';
import '../../packages/react-image-editor/dist/styles.css';
const w = window as any;
w.api = { EditorEngine, ensureFontLoaded, fabric, KOREAN_LABELS };
const originalBind = EditorController.prototype.requestBind;
EditorController.prototype.requestBind = function (...args) { w.controller = this; return originalBind.apply(this, args); };
const root = createRoot(document.getElementById('root')!);
w.mount = (props = {}) => {
  w.events = []; w.blobs = {};
  root.render(<ImageEditor key={Math.random()} mode="full" height={760} width="100%" exportFormats={['png', 'jpeg', 'webp', 'pdf', 'svg', 'json']}
    onSaved={blob => { w.blobs.saved = blob; w.events.push({ event: 'saved', type: blob.type }); }}
    onImageLoaded={() => w.events.push({ event: 'loaded' })}
    onHistoryChange={state => w.events.push({ event: 'history', ...state })}
    onDirtyChange={dirty => w.events.push({ event: 'dirty', dirty })}
    onError={error => w.events.push({ event: 'error', ...error })} {...props} />);
};
w.newEngine = async (options = {}) => {
  if (w.engine) await w.engine.destroy();
  const canvas = document.createElement('canvas'); document.body.appendChild(canvas);
  w.engine = await EditorEngine.create(canvas, { width: 640, height: 480, ...options });
  return w.engine;
};
w.ready = true;
