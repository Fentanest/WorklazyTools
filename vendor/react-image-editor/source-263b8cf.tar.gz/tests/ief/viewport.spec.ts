import { test, expect } from '@playwright/test';

async function mount(page: any) {
  await page.goto('/'); await page.waitForFunction(() => (window as any).ready);
  await page.evaluate(() => (window as any).mount({ initialTool: 'select', fontResolver: () => 'local', backgroundRemovalLoader: async () => ({ removeBackground: async (blob: Blob) => blob }) }));
  await page.waitForFunction(() => (window as any).events.some((e: any) => e.event === 'loaded'));
}
async function inside(page: any, selector: string) {
  const result = await page.locator(selector).evaluate((node: HTMLElement) => {
    const rect = (el: Element) => { const r = el.getBoundingClientRect(); return { left: r.left, top: r.top, right: r.right, bottom: r.bottom }; };
    return { menu: rect(node), items: [...node.querySelectorAll('button,input,select,label')].map(rect), hits: [...node.querySelectorAll('button,select')].map(el => { const r = el.getBoundingClientRect(); const target = document.elementFromPoint((r.left+r.right)/2,(r.top+r.bottom)/2); return { text: el.textContent, reachable: target === el || el.contains(target) }; }), viewport: { width: innerWidth, height: innerHeight } };
  });
  for (const r of [result.menu, ...result.items]) {
    expect(r.left).toBeGreaterThanOrEqual(-.5); expect(r.top).toBeGreaterThanOrEqual(-.5);
    expect(r.right).toBeLessThanOrEqual(result.viewport.width + .5); expect(r.bottom).toBeLessThanOrEqual(result.viewport.height + .5);
  }
  for (const hit of result.hits) expect(hit.reachable, String(hit.text)).toBe(true);
  return result;
}
for (const width of [390, 360, 320]) {
  test(`${width}px: every flyout and popover item fits, and Escape restores keyboard focus`, async ({ page }, info) => {
    await page.setViewportSize({ width, height: 1000 }); await mount(page); const results = [];
    for (const name of ['Draw — more tools', 'Magic — more tools', 'Canvas — more tools']) {
      const opener = page.getByRole('button', { name, exact: true }); await opener.focus(); await page.keyboard.press('Enter');
      await expect(page.getByRole('menu')).toBeVisible(); results.push({ name, ...await inside(page, '.asp-rail__flyout') });
      await page.keyboard.press('Tab'); await expect(page.getByRole('button', { name: 'Close', exact: true })).toBeFocused();
      await page.keyboard.press('Escape'); await expect(page.getByRole('menu')).toHaveCount(0); await expect(opener).toBeFocused();
      await page.keyboard.press('Enter'); await page.keyboard.press('Tab'); await page.keyboard.press('Tab'); await expect(page.getByRole('menuitem').first()).toBeFocused();
      await page.keyboard.press('Escape'); await expect(page.getByRole('menu')).toHaveCount(0); await expect(opener).toBeFocused();
    }
    for (const [name, selector] of [['Image', '.asp-menu--right:not(.asp-menu--export)'], ['Export', '.asp-menu--export'], ['Edit history', '.asp-menu--history']]) {
      const opener = page.getByRole('button', { name, exact: true }); await opener.focus(); await page.keyboard.press('Enter');
      await expect(page.locator(selector)).toBeVisible(); results.push({ name, ...await inside(page, selector) }); await page.keyboard.press('Escape');
      await expect(page.locator(selector)).toHaveCount(0); await expect(opener).toBeFocused();
    }
    await page.evaluate(() => (window as any).controller.currentEngine.addText('Align sample', { color: '#000', fontSize: 20, fontFamily: 'Arial' }));
    const align = page.getByRole('button', { name: 'Align', exact: true }); await align.click(); results.push({ name: 'Align', ...await inside(page, '.asp-layers__alignmenu') }); await page.keyboard.press('Escape');
    await expect(page.locator('.asp-layers__alignmenu')).toHaveCount(0); await expect(align).toBeFocused();
    await info.attach('popover-rects', { body: JSON.stringify(results), contentType: 'application/json' }); await page.screenshot({ path: info.outputPath('workspace.png'), fullPage: true });
  });
}
test('desktop flyout preference is unchanged when it fits', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 }); await mount(page);
  for (const name of ['Draw — more tools', 'Magic — more tools', 'Canvas — more tools']) {
    await page.getByRole('button', { name, exact: true }).click(); await inside(page, '.asp-rail__flyout');
    expect(await page.locator('.asp-rail__flyout').evaluate(el => (el as HTMLElement).style.translate)).toBe('');
    await page.keyboard.press('Escape');
  }
});

test('desktop topbar popovers retain their natural CSS rectangles', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 }); await mount(page);
  for (const [name, selector] of [['Image', '.asp-menu--right:not(.asp-menu--export)'], ['Export', '.asp-menu--export'], ['Edit history', '.asp-menu--history']]) {
    await page.getByRole('button', { name, exact: true }).click(); await inside(page, selector);
    const rects = await page.locator(selector).evaluate((el: HTMLElement) => {
      const values = () => { const r = el.getBoundingClientRect(); return [r.left, r.top, r.width, r.height]; };
      const actual = values(), style = el.getAttribute('style'); el.removeAttribute('style'); const preferred = values();
      if (style !== null) el.setAttribute('style', style); return { actual, preferred };
    });
    rects.actual.forEach((value: number, index: number) => expect(value).toBeCloseTo(rects.preferred[index], 1));
    await page.keyboard.press('Escape');
  }
});

for (const width of [390, 360, 320]) {
  test(`${width}px: viewer export escapes its minimum-height clipping card`, async ({ page }) => {
    await page.setViewportSize({ width, height: 640 }); await mount(page);
    await page.evaluate(() => (window as any).mount({ mode: 'viewer', height: 200, width: '100%', fontResolver: () => 'local' }));
    await page.waitForFunction(() => (window as any).events.some((e: any) => e.event === 'loaded'));
    await page.getByRole('button', { name: 'Export', exact: true }).click();
    await inside(page, '.asp-menu--export'); await page.keyboard.press('Escape');
    await expect(page.locator('.asp-menu--export')).toHaveCount(0);
  });
}

test('PDF embeds lossless PNG with an alpha mask and keeps JPEG/WebP as lossy downloads', async ({ page }) => {
  await mount(page);
  const result = await page.evaluate(async () => {
    const w = window as any, engine = w.controller.currentEngine;
    engine.cancelCrop(); const blob = await engine.exportImage('pdf', 1, ['pdf']);
    const text = new TextDecoder('latin1').decode(await blob.arrayBuffer());
    return { mime: blob.type, dct: text.includes('/DCTDecode'), flate: text.includes('/FlateDecode'), mask: text.includes('/SMask'),
      jpeg: (await engine.exportImage('jpeg', 92, ['jpeg'])).type, webp: (await engine.exportImage('webp', 92, ['webp'])).type };
  });
  expect(result).toEqual({ mime: 'application/pdf', dct: false, flate: true, mask: true, jpeg: 'image/jpeg', webp: 'image/webp' });
});

test('flyout selection returns focus to its trigger without stealing later primary-tool focus', async ({ page }) => {
  await mount(page); const trigger = page.getByRole('button', { name: 'Magic — more tools', exact: true });
  await trigger.focus(); await page.keyboard.press('Enter'); await page.keyboard.press('Tab'); await page.keyboard.press('Tab');
  await page.keyboard.press('Tab'); await expect(page.getByRole('menuitem', { name: 'Remove background', exact: true })).toBeFocused();
  await page.keyboard.press('Enter'); await expect(trigger).toBeFocused();
  const primary = page.getByRole('button', { name: 'Crop & rotate', exact: true }); await primary.click(); await expect(primary).toBeFocused();
});
