"""Whole-scene PSNR against independently rendered, white-matted RGB reference."""
import json
import math
from pathlib import Path
import numpy as np
from PIL import Image, JpegImagePlugin
root = Path('.ief/d6-jpeg')
facts = json.loads((root / 'facts.json').read_text())

def rgb(path):
    image = Image.open(path).convert('RGBA')
    bg = Image.new('RGBA', image.size, 'white')
    return np.asarray(Image.alpha_composite(bg, image).convert('RGB'), dtype=np.float64)

def psnr(reference, path):
    image = rgb(path)
    assert image.shape == reference.shape
    mse = np.mean((reference - image) ** 2)
    return math.inf if mse == 0 else 10 * math.log10(255 ** 2 / mse)

rows = []
for s in facts['scenes']:
    name = s['id']
    reference = rgb(root / f'{name}.reference.png')
    before, after = [root / f'{name}.q{q}.jpeg' for q in [92, 95]]
    sampling = JpegImagePlugin.get_sampling(Image.open(after))
    # Same source + same WebP quality must preserve the prior validated export bytes.
    webp = root / f'{name}.q92.webp'
    old_webp = Path('.ief/fix-ie0b-scenes') / f'{name}.webp'
    unchanged = webp.read_bytes() == old_webp.read_bytes() if old_webp.exists() else None
    row = dict(id=name, psnr92=psnr(reference, before), psnr95=psnr(reference, after),
               bytes92=before.stat().st_size, bytes95=after.stat().st_size,
               sizeIncreasePercent=(after.stat().st_size / before.stat().st_size - 1) * 100,
               sampling=sampling, webpPSNR=psnr(reference, webp), webpBytes=webp.stat().st_size,
               webpUnchanged=unchanged)
    rows.append(row)
    assert row['psnr95'] >= 38, row
    assert sampling == 2, 'Expected browser JPEG 4:2:0'
    assert unchanged is not False, row
result = {**facts, 'metrics': rows, 'pass': True}
(root / 'metrics.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
