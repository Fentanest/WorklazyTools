import { test, expect } from '@playwright/test';
const mount = async (page: any, tool = 'crop') => {
  await page.goto('/');
  await page.waitForFunction(() => (window as any).ready);
  await page.evaluate((tool: string) => (window as any).mount({ initialTool: tool, initialRedactMode: 'solid', fontResolver: () => 'local' }), tool);
  await page.waitForFunction(() => (window as any).events.some((e: any) => e.event === 'loaded'));
};
test('390px crop and concealment regions can be specified using keyboard alone', async ({ page }, testInfo) => {
  await mount(page);
  await expect(page.getByRole('spinbutton', { name: 'Left', exact: true })).toBeVisible();
  // Reach every region field using Tab, then replace with keyboard events.
  for (const [name, value] of [['Left', '20'], ['Top', '30'], ['Width', '100'], ['Height', '80']]) {
    let found = false;
    for (let count = 0; count < 100; count++) {
      await page.keyboard.press('Tab');
      if (await page.getByRole('spinbutton', { name, exact: true }).evaluate(el => el === document.activeElement)) { found = true; break; }
    }
    expect(found).toBe(true);
    await page.keyboard.press('ControlOrMeta+a'); await page.keyboard.type(value);
  }
  const region = await page.evaluate(() => (window as any).controller.currentEngine.getMarquee());
  expect(region).toEqual({ left: 20, top: 30, width: 100, height: 80 });
  await page.keyboard.press('Tab');
  await page.screenshot({ path: testInfo.outputPath('390-crop.png'), fullPage: true });
  for (let i = 0; i < 100; i++) {
    if (await page.getByRole('button', { name: 'Apply crop', exact: true }).evaluate(el => el === document.activeElement)) break;
    await page.keyboard.press('Tab');
  }
  await page.keyboard.press('Enter');
  expect(await page.evaluate(() => (window as any).controller.currentEngine.isDirty)).toBe(true);
  await mount(page, 'redact');
  for (const [name, value] of [['Left', '10'], ['Top', '15'], ['Width', '110'], ['Height', '90']]) {
    let found = false;
    for (let count = 0; count < 100; count++) {
      await page.keyboard.press('Tab');
      if (await page.getByRole('spinbutton', { name, exact: true }).evaluate(el => el === document.activeElement)) { found = true; break; }
    }
    expect(found).toBe(true); await page.keyboard.press('ControlOrMeta+a'); await page.keyboard.type(value);
  }
  expect(await page.evaluate(() => (window as any).controller.currentEngine.getMarquee())).toEqual({ left: 10, top: 15, width: 110, height: 90 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390);
  await page.screenshot({ path: testInfo.outputPath('390-redact.png'), fullPage: true });
  await testInfo.attach('keyboard-regions', { body: JSON.stringify({ width: 390, crop: region, redact: { left: 10, top: 15, width: 110, height: 90 }, method: 'Tab and keyboard typing only' }), contentType: 'application/json' });
});
test('focus scopes shortcuts and a local family causes no external requests including SVG', async ({ page }) => {
  const external: string[] = [];
  page.on('request', req => { if (/^https?:/.test(req.url()) && !req.url().startsWith('http://127.0.0.1:4184')) external.push(req.url()); });
  await mount(page, 'text');
  await page.evaluate(async () => {
    const w = window as any;
    await w.api.ensureFontLoaded('Arial', () => 'local');
    w.controller.currentEngine.addText('local font', { color: '#000', fontSize: 20, fontFamily: 'Arial' });
    await w.controller.currentEngine.exportImage('svg', 92, ['svg']);
  });
  expect(external).toEqual([]);
  await page.locator('.asp-image-editor').focus();
  await page.keyboard.press('ControlOrMeta+z');
  expect(await page.evaluate(() => (window as any).controller.currentEngine.canRedo)).toBe(true);
  await page.locator('#outside').focus(); await page.keyboard.press('ControlOrMeta+Shift+z');
  expect(await page.evaluate(() => (window as any).controller.currentEngine.canRedo)).toBe(true);
});
test('all output paths gate cancellation, commit uses raster, dirty baseline survives branching and cap', async ({ page }) => {
  await mount(page);
  const result = await page.evaluate(async () => {
    const w = window as any, engine = w.controller.currentEngine;
    const calls: any[] = [];
    engine.configureIntegration({ onBeforeExport: (c: any) => { calls.push(c); return 'cancel'; } });
    for (const format of ['png', 'jpeg', 'webp', 'pdf', 'svg', 'json']) {
      try { await engine.exportImage(format, 92, [format], 'download'); throw new Error('not cancelled'); }
      catch (e: any) { if (e.code !== 'export-cancelled') throw e; }
    }
    try { await engine.exportTemplate(); } catch (e: any) { if (e.code !== 'export-cancelled') throw e; }
    engine.configureIntegration({}); engine.cancelCrop(); engine.markClean();
    engine.setArtboard({ width: 320, height: 200 }); const artboardDirty = engine.isDirty;
    await engine.undo(); const undoClean = !engine.isDirty;
    await engine.redo(); engine.markClean();
    for (let i = 0; i < 65; i++) engine.setArtboard({ width: 321 + i, height: 200 });
    const cappedDirty = engine.isDirty && engine.historyEntries.length === 50;
    await engine.undo(); engine.setArtboard({ width: 999, height: 200 }); const branchDirty = engine.isDirty;
    w.mount({ commitFormat: 'png', exportFormats: ['svg'], onBeforeExport: (c: any) => { w.commitContext = c; return 'proceed'; } });
    return { calls, artboardDirty, undoClean, cappedDirty, branchDirty };
  });
  expect(result.calls).toHaveLength(7);
  expect(result.artboardDirty && result.undoClean && result.cappedDirty && result.branchDirty).toBe(true);
  await page.waitForFunction(() => (window as any).events.some((e: any) => e.event === 'loaded'));
  await page.evaluate(() => (window as any).controller.save());
  expect(await page.evaluate(() => (window as any).blobs.saved.type)).toBe('image/png');
  expect(await page.evaluate(() => (window as any).commitContext.path)).toBe('commit');
});
test('template remote source is rejected, nested markings survive clone, undo does not clear session flag', async ({ page }) => {
  await mount(page);
  expect(await page.evaluate(async () => {
    const w = window as any, e = w.controller.currentEngine;
    e.cancelCrop(); e.addRedactionMarquee(); await e.applyRedaction('solid');
    const before = e.hasConcealment; await e.undo(); const afterUndo = e.hasConcealment;
    const t = JSON.parse(e.exportScene()); t.snapshot.json.objects[0].src = 'https://invalid.example/source.png';
    let code; try { await e.loadScene(JSON.stringify(t)); } catch (error: any) { code = error.code; }
    const child = new w.api.fabric.Rect({ width: 20, height: 20 }); child.set('aspConcealment', true);
    const group = new w.api.fabric.Group([new w.api.fabric.Group([child])]);
    const clone = await group.clone();
    return { before, afterUndo, code, clone: clone.toObject().objects[0].objects[0].aspConcealment };
  })).toEqual({ before: true, afterUndo: true, code: 'template-remote-source', clone: true });
});

test('independent caps also cover blob URL bypass and flatten renders at target resolution', async ({ page }) => {
  await page.goto('/'); await page.waitForFunction(() => (window as any).ready);
  const result = await page.evaluate(async () => {
    const w = window as any;
    const source = document.createElement('canvas'); source.width = 200; source.height = 100;
    const ctx = source.getContext('2d')!; ctx.fillStyle = '#edab44'; ctx.fillRect(0, 0, 200, 100);
    const data = source.toDataURL(); const blob = await (await fetch(data)).blob(); const url = URL.createObjectURL(blob);
    const e = await w.newEngine({ resolutionLimits: { inputMaxDimension: 40, limitUrlInputs: true, cropMaxPixels: 1000, artboardMaxPixels: 1000, flattenMaxPixels: 2000000 } });
    await e.loadImage(url); URL.revokeObjectURL(url);
    const input = { width: e.baseImage.width, height: e.baseImage.height };
    const errors: string[] = [];
    try { e.setArtboard({ width: 100, height: 100 }); } catch (error: any) { errors.push(error.code); }
    try { await e.flattenScene({ width: 2000, height: 2000 }); } catch (error: any) { errors.push(error.code); }
    e.beginCrop(null); e.setMarquee({ left: 10, top: 10, width: 100, height: 100 }); e.applyCropRegion();
    const cropped = await createImageBitmap(await e.exportImage('png', 92, ['png']));
    const cropPixels = cropped.width * cropped.height; cropped.close();
    e.clearCropRegion(); e.addRedactionMarquee(); await e.applyRedaction('solid');
    const reference = e.canvas.toCanvasElement(2).toDataURL('image/png');
    const merged = await e.flattenScene({ width: 1280, height: 960 });
    const actual = await merged.exportImage('png', 92, ['png']); const b64 = await new Promise(resolve => { const r = new FileReader(); r.onload = () => resolve(r.result); r.readAsDataURL(actual); });
    const equal = reference === b64;
    await merged.destroy();
    return { input, errors, cropPixels, equal };
  });
  expect(result.input).toEqual({ width: 40, height: 20 });
  expect(result.errors).toEqual(['resolution-limit', 'resolution-limit']);
  expect(result.cropPixels).toBeLessThanOrEqual(1000);
  expect(result.equal).toBe(true);
});
test('injected Korean labels reach tool names, buttons, aria and history', async ({ page }) => {
  await mount(page);
  await page.evaluate(() => (window as any).mount({ labels: (window as any).api.KOREAN_LABELS, initialTool: 'crop' }));
  await expect(page.getByRole('button', { name: '자르기 적용', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: '왼쪽으로 회전', exact: true })).toBeVisible();
  await expect(page.getByRole('spinbutton', { name: '너비', exact: true })).toBeVisible();
  await page.getByRole('button', { name: '편집 기록', exact: true }).click();
  await expect(page.getByText('이미지 열기', { exact: true })).toBeVisible();
});
test('save baseline does not swallow edits made while export policy is pending', async ({ page }) => {
  await mount(page);
  expect(await page.evaluate(async () => {
    const w = window as any;
    let release!: (value: string) => void;
    w.mount({ onBeforeExport: () => new Promise(resolve => { release = resolve; }) });
    await new Promise<void>(resolve => { const timer = setInterval(() => { if (w.events.some((e: any) => e.event === 'loaded')) { clearInterval(timer); resolve(); } }, 10); });
    const saving = w.controller.save();
    while (!release) await new Promise(resolve => setTimeout(resolve, 5));
    w.controller.currentEngine.setArtboard({ width: 123, height: 100 });
    release('proceed'); await saving;
    return w.controller.currentEngine.isDirty;
  })).toBe(true);
});
test('background replacement stub preserves z-order and base role under concealment', async ({ page }) => {
  await page.goto('/'); await page.waitForFunction(() => (window as any).ready);
  expect(await page.evaluate(async () => {
    const w = window as any;
    const canvas = document.createElement('canvas'); canvas.width = 200; canvas.height = 100;
    const x = canvas.getContext('2d')!; x.fillStyle = '#aabbcc'; x.fillRect(0, 0, 200, 100);
    const blob = await (await fetch(canvas.toDataURL())).blob();
    const engine = await w.newEngine({ backgroundRemovalLoader: async () => ({ removeBackground: async () => blob }) });
    await engine.loadImage(blob); engine.baseImage.set('aspRole', 'base');
    engine.addRedactionMarquee(); await engine.applyRedaction('solid');
    await engine.removeImageBackground('replace');
    return engine.canvas.getObjects().map((o: any) => ({ role: o.get('aspRole'), id: o.get('aspId') }));
  })).toEqual([{ role: 'base', id: 'base' }, { role: 'redaction', id: expect.any(String) }]);
});
test('V1 counterexamples and proceed/no-concealment output paths remain gated', async ({ page }) => {
  await page.goto('/'); await page.waitForFunction(() => (window as any).ready);
  const facts = await page.evaluate(async () => {
    const w = window as any, e = await w.newEngine();
    const source = document.createElement('canvas'); source.width = 80; source.height = 60;
    source.getContext('2d')!.fillRect(0, 0, 80, 60); const src = source.toDataURL();
    await e.loadImage(src);
    const calls: any[] = []; e.configureIntegration({ onBeforeExport: (c: any) => { calls.push(c); return 'proceed'; } });
    for (const format of ['png', 'jpeg', 'webp', 'pdf', 'svg', 'json']) await e.exportImage(format, 92, [format]);
    await e.exportTemplate(); const cleanCalls = calls.splice(0);
    e.addRedactionMarquee(); await e.applyRedaction('solid');
    const original = e.canvas.getObjects().find((o: any) => o.get('aspRole') === 'redaction');
    e.canvas.setActiveObject(original); await e.duplicateActive();
    e.deleteLayer(original.get('aspId'));
    const duplicateMarker = e.canvas.getObjects().find((o: any) => o.get('aspRole') === 'redaction').get('aspConcealment');
    const svg = await (await e.exportImage('svg', 92, ['svg'])).text();
    const json = await (await e.exportImage('json', 92, ['json'])).text();
    await e.copy(); await e.paste(); const pasteMarker = e.canvas.getActiveObject().get('aspConcealment');
    await e.undo(); const undo = e.hasConcealment; await e.redo(); const redo = e.hasConcealment;
    const template = await e.exportTemplate();
    const fresh = await w.api.EditorEngine.create(document.createElement('canvas'), { width: 640, height: 480 });
    await fresh.loadScene(template); const roundtrip = JSON.parse(fresh.exportScene()).concealmentEverApplied;
    await fresh.loadImage(src); const replaced = fresh.hasConcealment; await fresh.destroy();
    return { cleanFlags: cleanCalls.map((c: any) => c.hasConcealment), duplicateMarker, pasteMarker, undo, redo, roundtrip, replaced,
      riskyProceedHasOriginal: svg.includes('data:image/png;base64,') && JSON.parse(json).objects.some((o: any) => o.aspId === 'base'),
      concealedFlags: calls.map((c: any) => c.hasConcealment) };
  });
  expect(facts.cleanFlags).toEqual(Array(7).fill(false));
  expect(facts.duplicateMarker && facts.pasteMarker && facts.undo && facts.redo && facts.roundtrip && facts.riskyProceedHasOriginal).toBe(true);
  expect(facts.replaced).toBe(false);
  expect(facts.concealedFlags.every(Boolean)).toBe(true);
});

test('JPEG-only default reaches real downloads, restores slider quality, and isolates forced commits', async ({ page }) => {
  await page.goto('/'); await page.waitForFunction(() => (window as any).ready);
  await page.evaluate(() => {
    const w = window as any;
    w.mount({ jpegExportQuality: 95, exportQuality: 92, exportFormats: ['jpeg', 'webp'],
      commitFormat: 'jpeg', fontResolver: () => 'local' });
  });
  await page.waitForFunction(() => (window as any).events.some((e: any) => e.event === 'loaded'));
  const result = await page.evaluate(async () => {
    const w = window as any, c = w.controller, e = c.currentEngine;
    const calls: unknown[] = [], original = e.exportImage.bind(e);
    e.exportImage = (...args: any[]) => { calls.push(args); return original(...args); };
    const initial = c.getSnapshot().exportQ;
    await c.download();
    c.setExportFormat('webp'); const webp = c.getSnapshot().exportQ;
    await c.download(); await c.save();
    c.setExportFormat('jpeg'); const restored = c.getSnapshot().exportQ;
    return { initial, webp, restored, calls };
  });
  expect(result).toEqual({ initial: 95, webp: 92, restored: 95, calls: [
    ['jpeg', 95, ['jpeg', 'webp'], 'download'],
    ['webp', 92, ['jpeg', 'webp'], 'download'],
    ['jpeg', 95, ['jpeg'], 'commit'],
  ] });
});
