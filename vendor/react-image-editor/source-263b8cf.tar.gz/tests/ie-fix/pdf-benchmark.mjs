import fs from 'node:fs';import{chromium}from'@playwright/test';
const phase=process.env.PDF_BENCHMARK_PHASE??'after',out='/tmp/sol-ie-fix-ie0b/pdf-'+phase;fs.mkdirSync(out,{recursive:true});const browser=await chromium.launch({executablePath:'/home/better0101/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome'}),page=await browser.newPage();await page.goto('http://127.0.0.1:4194');await page.waitForFunction(()=>window.ready);const rows=[];
try{for(const name of['actual-photo-solid','actual-screen-solid','actual-photo-blur','actual-screen-pixelate','actual-nested-group','actual-background-removal']){
 const file=name==='actual-background-removal'?'.ief/ie0b/bg-scene/actual-background-then-solid.reference.png':`.ief/supplement/exports/${name}.reference.png`;
 const source='data:image/png;base64,'+fs.readFileSync(file).toString('base64');
 const result=await page.evaluate(async({source,name,phase})=>{const e=await window.newEngine({width:640,height:480});await e.loadImage(source);e.baseImage.set({left:0,top:0,originX:'left',originY:'top',scaleX:1,scaleY:1});e.canvas.renderAll();await e.exportImage('pdf',92,['pdf']);const url=e.exportPdf.toString().match(/import\(["']([^"']*jspdf[^"']*)["']\)/)[1],{jsPDF}=await import(url),rows=[];
 if(phase==='before' && /artboardDataUrl\(["']png/.test(e.exportPdf.toString()))throw Error('Before measurement requires the pre-fix product source');
 for(const compression of(phase==='before'?['JPEG','FAST','SLOW']:['PNG-PDF']))for(let repeat=0;repeat<5;repeat++){const start=performance.now();let blob;
  if(compression==='JPEG'||compression==='PNG-PDF')blob=await e.exportImage('pdf',92,['pdf']);else{const png=e.artboardDataUrl('png',1),pdf=new jsPDF({orientation:'landscape',unit:'px',format:[640,480]});pdf.addImage(png,'PNG',0,0,640,480,undefined,compression);blob=pdf.output('blob')}
  rows.push({name,compression,repeat,bytes:blob.size,milliseconds:performance.now()-start});
 }
 return rows;},{source,name,phase});rows.push(...result);console.log(name,result.filter(x=>x.repeat===0));}
}finally{fs.writeFileSync(out+'/rows.json',JSON.stringify(rows,null,2));await browser.close()}
