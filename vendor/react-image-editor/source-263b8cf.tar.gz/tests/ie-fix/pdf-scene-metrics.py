from pathlib import Path
from PIL import Image
import numpy as np,json,re,base64,subprocess,math
root=Path('.ief/fix-ie0b-scenes');facts=json.loads((root/'facts.json').read_text());rows=[]
for fact in facts:
 name=fact['id'];reference=Image.open(root/f'{name}.reference.png').convert('RGBA')
 for kind,src in [('svg',re.search(r'data:image/png;base64,([A-Za-z0-9+/=]+)',(root/f'{name}.svg').read_text())[1]),('json',json.loads((root/f'{name}.json').read_text())['objects'][0]['src'].split(',')[1]),('template',json.loads((root/f'{name}.template.json').read_text())['snapshot']['json']['objects'][0]['src'].split(',')[1])]:
  (root/f'{name}.{kind}-base.png').write_bytes(base64.b64decode(src))
 for extracted in root.glob(f'{name}.pdfimage-*.png'):extracted.unlink()
 subprocess.run(['pdfimages','-png',str(root/f'{name}.pdf'),str(root/f'{name}.pdfimage')],check=True)
 pdf=Image.open(root/f'{name}.pdfimage-000.png').convert('RGBA');mask=root/f'{name}.pdfimage-001.png'
 if mask.exists():pdf.putalpha(Image.open(mask).convert('L'))
 pdf.save(root/f'{name}.pdf-rgba.png')
 for format,file in [('png',f'{name}.png'),('jpeg',f'{name}.jpeg'),('webp',f'{name}.webp'),('pdf',f'{name}.pdf-rgba.png'),('svg',f'{name}.svg-base.png'),('json',f'{name}.json-base.png'),('template',f'{name}.template-base.png')]:
  image=Image.open(root/file).convert('RGBA');delta=np.abs(np.asarray(image).astype(int)-np.asarray(reference).astype(int)).max(axis=2);fraction=float(np.mean(delta<=1));maximum=int(delta.max());lossless=format not in['jpeg','webp'];row={'scene':name,'format':format,'bytes':(root/f'{name}.{format if format!="template"else "template.json"}').stat().st_size,'lossless':lossless,'fractionChannelDeltaLE1':fraction,'maxChannelDelta':maximum}
  if lossless:row['aPass']=fraction>=.9999 and maximum<=8
  else:
   def white(im):bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);return np.asarray(bg.convert('RGB')).astype(float)
   mse=np.mean((white(image)-white(reference))**2);psnr=10*math.log10(255**2/mse)if mse else None;row['PSNRdB']=psnr;row['aPass']=psnr is None or psnr>=38
  if fact['mode']=='solid':
   sample=np.asarray(image)[172:288,142:498,:3].astype(int);d=np.abs(sample-np.array([11,15,26])).max(axis=2);row['solidFractionDeltaLE6']=float(np.mean(d<=6));row['solidMaxDelta']=int(d.max());row['bPass']=bool(d.max()==0 if lossless else np.mean(d<=6)>=.995 and d.max()<=16)
  rows.append(row)
 fact['payloadPass']=fact['unchanged']and fact['originalOccurrences']==[0,0,0]and fact['sourceCounts']==[1,1]and fact['jsonObjects']==fact['templateObjects']==1 and not fact['templateFlag']and not fact['historyKeys']
summary={'rows':rows,'facts':facts,'pdfAllLosslessPass':all(r['aPass']and r.get('bPass',True)for r in rows if r['format']=='pdf'),'knownJpegFailures':[r for r in rows if r['format']=='jpeg'and not r['aPass']]};(root/'metrics.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'PDF':[(r['scene'],r['bytes'],r['fractionChannelDeltaLE1'],r['maxChannelDelta'])for r in rows if r['format']=='pdf'],'knownJpegFailures':len(summary['knownJpegFailures'])},indent=2));assert summary['pdfAllLosslessPass']and all(f['payloadPass']for f in facts)
